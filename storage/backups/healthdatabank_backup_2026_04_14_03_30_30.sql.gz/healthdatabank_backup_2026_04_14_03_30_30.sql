-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: mysql    Database: healthdatabank
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type` enum('User','Researcher','HealthcareProvider','Admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('ACTIVE','DEACTIVATED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES ('038cd94a-c6bd-481c-b707-2c60d59d9d5e','User','Burley Morissette','loconner@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('051f76f1-0e9b-467c-b8e8-f1ededdffcf1','User','Dee Bogisich','schulist.drew@example.net','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','User','Geofferey','Researcher@email.com','ACTIVE','2026-04-13 02:34:10','2026-04-13 02:34:10'),('0c861910-7fb9-4979-8fd0-b3ac02fe0625','User','Dr. Kiana Lesch MD','larson.keara@example.net','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('0cc3c479-07f2-4a67-93ac-7866b238daeb','User','Lorna Goldner','merritt.mraz@example.org','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('1a709ffd-5518-40dc-909d-6e744676beb7','Admin','Test Admin','admin@example.com','ACTIVE','2026-04-12 23:21:09','2026-04-12 23:21:09'),('2bddb97b-2da4-4521-a6cf-f9d3a3558469','User','test','usertest3@email.com','ACTIVE','2026-04-14 01:21:12','2026-04-14 01:21:12'),('2cc44de1-c03a-422a-a9c5-14018c8ea074','User','Provider','provider@email.com','ACTIVE','2026-04-14 00:23:08','2026-04-14 00:23:08'),('32586ad1-7956-476e-b341-c72682de18dc','User','Demo User 4','demo4@example.com','ACTIVE','2026-04-13 01:18:38','2026-04-13 01:18:38'),('3467c3ce-47fb-407e-b44c-2deef72f4747','User','Corbin Zieme','schmitt.theron@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('3a47a409-6bb9-4719-b96f-78746724d6bd','HealthcareProvider','Test Patients','patients@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('58a142ac-39ba-462a-bda0-864753aaf140','User','Fernando Gorczany','rudy.bartoletti@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('5c2eaee3-1604-4ed6-ba1e-475ed70600f8','User','Harry Stracke IV','demetris99@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('600197de-bdf8-4a97-9238-53d514debc2e','User','Maxime Ledner','smacejkovic@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('608e6deb-5192-4a2c-8a4b-b8f49414bcfe','User','Admin','admin@email.com','ACTIVE','2026-04-14 01:39:29','2026-04-14 01:39:29'),('699950d5-86ca-44ec-9473-e64f5659b004','User','Usertest','Usertest@email.com','ACTIVE','2026-04-12 23:21:47','2026-04-12 23:21:47'),('70508027-2f1f-4fb5-8c82-3ec7887dfe91','User','Researcher','Researcher2@email.com','ACTIVE','2026-04-14 00:10:04','2026-04-14 00:10:04'),('7c242f03-b521-40ae-bc00-6a30ff48310b','User','Norbert Brown','willy.mayer@example.net','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('7c28e0f1-d0e6-4422-a7be-563b3363bcfa','User','Tanya Orn','alverta.heathcote@example.org','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('817e9947-0a90-45e8-9dd0-d1e7de1e443c','User','Prof. Arely Wisoky','xkuhlman@example.net','ACTIVE','2026-04-12 23:21:11','2026-04-12 23:21:11'),('86796d79-f9cc-4a19-bb25-28cc8f9928ec','User','Mr. Lloyd Huel Sr.','veum.ashlee@example.com','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('9209c193-fa25-432f-85e5-96e96ade32ed','User','Demo User 3','demo3@example.com','ACTIVE','2026-04-13 01:18:29','2026-04-13 01:18:29'),('9929bc57-d157-467a-9d9c-24b56a6863e9','User','Demo User 5','demo5@example.com','ACTIVE','2026-04-13 01:18:49','2026-04-13 01:18:49'),('a8d3c258-f481-4b56-9052-081c2078d854','Researcher','Test Res','res@example.com','ACTIVE','2026-04-12 23:21:09','2026-04-12 23:21:09'),('b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','User','Prof. Madisyn West','reagan.smith@example.org','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('c91f016f-6a27-44a5-ada0-1cbda7f96af9','User','Test User','test@example.com','ACTIVE','2026-04-12 23:21:08','2026-04-12 23:21:08'),('c98b30fa-2642-4778-9e81-78bee05a62ec','User','Eva Schmidt','abotsford@example.org','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','User','Demo User 2','demo2@example.com','ACTIVE','2026-04-13 01:18:18','2026-04-13 01:18:18'),('e23f917d-388f-4bcf-bbd3-1b55e2fc0805','User','Hunter Kunde','turcotte.chanelle@example.net','ACTIVE','2026-04-12 23:21:11','2026-04-12 23:21:11'),('e7e74f59-fd88-47f2-8de8-bf345109b9e9','User','Test Summary','summary@example.com','ACTIVE','2026-04-12 23:21:09','2026-04-12 23:21:09'),('f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','User','Amos Blick','kareem60@example.org','ACTIVE','2026-04-12 23:21:10','2026-04-12 23:21:10'),('fb04e079-f2c1-45b1-9733-71aa5e52896c','User','Demo User 1','demo1@example.com','ACTIVE','2026-04-13 01:18:07','2026-04-13 01:18:07'),('fd8e3f6f-f555-4aa5-b65a-f489aba8375f','HealthcareProvider','Test Provider','provider@example.com','ACTIVE','2026-04-12 23:21:09','2026-04-12 23:21:09');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aggregated_data`
--

DROP TABLE IF EXISTS `aggregated_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aggregated_data` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metrics` json DEFAULT NULL,
  `anonymization_level` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `aggregated_data_report_id_foreign` (`report_id`),
  CONSTRAINT `aggregated_data_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aggregated_data`
--

LOCK TABLES `aggregated_data` WRITE;
/*!40000 ALTER TABLE `aggregated_data` DISABLE KEYS */;
INSERT INTO `aggregated_data` VALUES ('115e785a-4a05-4376-abdd-65b2af75d677','fab5dacf-032a-40e1-8fe3-f205ef5550b7','{\"weight\": 314, \"meals_ate\": 1, \"days_slept\": 1, \"heart_rate\": 74}',1),('1fbc9002-df73-48e5-90a1-c55a7aac9ef6','4b28c3f4-b389-4365-bc4d-3554087d9ce8','{\"weight\": 134, \"meals_ate\": 2, \"days_slept\": 4, \"heart_rate\": 174}',1),('4f55e4ca-f33e-40c6-98e6-64df1eeaf07d','dbe4967b-89d8-4069-8aa8-8225fb9d2ef4','{\"weight\": 310, \"meals_ate\": 3, \"days_slept\": 2, \"heart_rate\": 162}',1),('566f04b8-69e3-4a33-9476-9bd98e6882aa','bb7abc7d-6f9e-47e9-a1ef-e171093355ca','{\"weight\": 339, \"meals_ate\": 4, \"days_slept\": 1, \"heart_rate\": 96}',1),('808a06e3-5b71-4152-9230-66815ac8e0fb','951a79c3-145a-45bd-b041-ad5478445b5a','{\"weight\": 258, \"meals_ate\": 4, \"days_slept\": 2, \"heart_rate\": 72}',1),('86c1cd56-506c-438e-9c7b-e07060146e03','b5f72d39-c547-472d-a0c5-d0babcbf6060','{\"weight\": 361, \"meals_ate\": 2, \"days_slept\": 4, \"heart_rate\": 152}',1);
/*!40000 ALTER TABLE `aggregated_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `route` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta` json DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `audit_logs_actor_id_action_type_index` (`actor_id`,`action_type`),
  CONSTRAINT `audit_logs_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audits`
--

DROP TABLE IF EXISTS `audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auditable_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_values` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `new_values` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(1023) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audits_user_id_user_type_index` (`user_id`,`user_type`),
  KEY `audits_auditable_id_auditable_type_index` (`auditable_id`,`auditable_type`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audits`
--

LOCK TABLES `audits` WRITE;
/*!40000 ALTER TABLE `audits` DISABLE KEYS */;
INSERT INTO `audits` VALUES (1,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-12 23:21:48','2026-04-12 23:21:48'),(2,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:21:51','2026-04-12 23:21:51'),(3,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:22:30','2026-04-12 23:22:30'),(4,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:30:30','2026-04-12 23:30:30'),(5,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"week\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:30:48','2026-04-12 23:30:48'),(6,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:30:50','2026-04-12 23:30:50'),(7,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:39:00','2026-04-12 23:39:00'),(8,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"week\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:39:07','2026-04-12 23:39:07'),(9,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"month\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:39:09','2026-04-12 23:39:09'),(10,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:43:07','2026-04-12 23:43:07'),(11,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:44:44','2026-04-12 23:44:44'),(12,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-12 23:55:19','2026-04-12 23:55:19'),(13,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:00:35','2026-04-13 00:00:35'),(14,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"weight\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:00:54','2026-04-13 00:00:54'),(15,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"hr\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:00:57','2026-04-13 00:00:57'),(16,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"weight\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:01:07','2026-04-13 00:01:07'),(17,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:05:50','2026-04-13 00:05:50'),(18,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"weight\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:06:02','2026-04-13 00:06:02'),(19,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:30:07','2026-04-13 00:30:07'),(20,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:32:10','2026-04-13 00:32:10'),(21,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"hr\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:32:27','2026-04-13 00:32:27'),(22,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 00:34:08','2026-04-13 00:34:08'),(23,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:13:56','2026-04-13 02:13:56'),(24,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:14:49','2026-04-13 02:14:49'),(25,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:16:08','2026-04-13 02:16:08'),(26,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:26:46','2026-04-13 02:26:46'),(27,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"weight\",\"group_by\":\"day\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:26:57','2026-04-13 02:26:57'),(28,'App\\Models\\User','699950d5-86ca-44ec-9473-e64f5659b004','logout',NULL,NULL,'[]','[]','http://localhost/logout','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-13 02:33:17','2026-04-13 02:33:17'),(29,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-13 02:34:10','2026-04-13 02:34:10'),(30,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:34:16','2026-04-13 02:34:16'),(31,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:34:34','2026-04-13 02:34:34'),(32,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:35:05','2026-04-13 02:35:05'),(33,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-13 02:41:01','2026-04-13 02:41:01'),(34,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','logout',NULL,NULL,'[]','[]','http://localhost/logout','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-13 03:05:28','2026-04-13 03:05:28'),(35,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-13 03:05:56','2026-04-13 03:05:56'),(36,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','login_success',NULL,NULL,'[]','[]','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-13 03:06:09','2026-04-13 03:06:09'),(37,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','researcher_cohort_created',NULL,NULL,'[]','{\"cohort_id\":\"31fdd05b-6957-4938-b0ac-c2b88edbf093\",\"estimated_size\":25,\"filters\":{\"account_type\":\"User\"},\"version\":1}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,researcher,outcome:success','2026-04-13 03:07:46','2026-04-13 03:07:46'),(38,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','researcher_cohort_created',NULL,NULL,'[]','{\"cohort_id\":\"40b4b084-1620-43c1-bd47-65cd754b4ed1\",\"estimated_size\":25,\"filters\":{\"account_type\":\"User\"},\"version\":1}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,researcher,outcome:success','2026-04-13 03:10:28','2026-04-13 03:10:28'),(39,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','researcher_cohort_created',NULL,NULL,'[]','{\"cohort_id\":\"44785ce1-5a45-4e2e-b181-0e4a0744e601\",\"estimated_size\":25,\"filters\":{\"account_type\":\"User\"},\"version\":1}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,researcher,outcome:success','2026-04-13 03:32:18','2026-04-13 03:32:18'),(40,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','researcher_cohort_created',NULL,NULL,'[]','{\"cohort_id\":\"caf795e9-8469-46cc-9a4b-89d1e4332b55\",\"estimated_size\":25,\"filters\":{\"account_type\":\"User\"},\"version\":1}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,researcher,outcome:success','2026-04-13 03:33:39','2026-04-13 03:33:39'),(41,'App\\Models\\User','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','researcher_aggregated_report_generated',NULL,NULL,'[]','{\"researcher_account_id\":\"097bf7e1-30f7-4d9e-b2b7-86a13bdc2064\",\"population_size\":25,\"from\":\"2026-04-01\",\"to\":\"2026-04-14\",\"metrics\":[\"heart_rate\",\"weight\"],\"filters\":{\"account_type\":\"User\"}}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','researcher,success','2026-04-13 04:39:41','2026-04-13 04:39:41'),(42,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-14 00:08:39','2026-04-14 00:08:39'),(43,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-14 00:09:01','2026-04-14 00:09:01'),(44,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-14 00:09:15','2026-04-14 00:09:15'),(45,'App\\Models\\User','70508027-2f1f-4fb5-8c82-3ec7887dfe91','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-14 00:10:05','2026-04-14 00:10:05'),(46,'App\\Models\\User','70508027-2f1f-4fb5-8c82-3ec7887dfe91','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 00:10:08','2026-04-14 00:10:08'),(47,'App\\Models\\User','70508027-2f1f-4fb5-8c82-3ec7887dfe91','logout',NULL,NULL,'[]','[]','http://localhost/logout','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-14 00:22:03','2026-04-14 00:22:03'),(48,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-14 00:23:08','2026-04-14 00:23:08'),(49,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 00:23:14','2026-04-14 00:23:14'),(50,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"051f76f1-0e9b-467c-b8e8-f1ededdffcf1\"}','http://localhost/provider/patients/051f76f1-0e9b-467c-b8e8-f1ededdffcf1','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 00:39:19','2026-04-14 00:39:19'),(51,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"051f76f1-0e9b-467c-b8e8-f1ededdffcf1\"}','http://localhost/provider/patients/051f76f1-0e9b-467c-b8e8-f1ededdffcf1','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 00:47:06','2026-04-14 00:47:06'),(52,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-14 01:20:14','2026-04-14 01:20:14'),(53,NULL,NULL,'login_failure',NULL,NULL,'[]','{\"reason\":\"invalid_credentials\"}','http://localhost/login','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:failure','2026-04-14 01:20:31','2026-04-14 01:20:31'),(54,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-14 01:21:13','2026-04-14 01:21:13'),(55,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:21:16','2026-04-14 01:21:16'),(56,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:30:31','2026-04-14 01:30:31'),(57,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:32:33','2026-04-14 01:32:33'),(58,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:33:14','2026-04-14 01:33:14'),(59,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"051f76f1-0e9b-467c-b8e8-f1ededdffcf1\"}','http://localhost/provider/patients/051f76f1-0e9b-467c-b8e8-f1ededdffcf1','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 01:33:30','2026-04-14 01:33:30'),(60,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"2bddb97b-2da4-4521-a6cf-f9d3a3558469\"}','http://localhost/provider/patients/2bddb97b-2da4-4521-a6cf-f9d3a3558469','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 01:34:11','2026-04-14 01:34:11'),(61,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"2bddb97b-2da4-4521-a6cf-f9d3a3558469\"}','http://localhost/provider/patients/2bddb97b-2da4-4521-a6cf-f9d3a3558469','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 01:34:11','2026-04-14 01:34:11'),(62,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_patient_record_view',NULL,NULL,'[]','{\"patient_id\":\"2bddb97b-2da4-4521-a6cf-f9d3a3558469\"}','http://localhost/provider/patients/2bddb97b-2da4-4521-a6cf-f9d3a3558469','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_record','2026-04-14 01:34:11','2026-04-14 01:34:11'),(63,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:35:33','2026-04-14 01:35:33'),(64,'App\\Models\\User','2cc44de1-c03a-422a-a9c5-14018c8ea074','provider_feedback_created',NULL,NULL,'[]','{\"patient_id\":\"2bddb97b-2da4-4521-a6cf-f9d3a3558469\",\"provider_account_id\":\"2cc44de1-c03a-422a-a9c5-14018c8ea074\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','provider,resource:patient_feedback,outcome:success','2026-04-14 01:35:42','2026-04-14 01:35:42'),(65,'App\\Models\\User','2bddb97b-2da4-4521-a6cf-f9d3a3558469','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:35:53','2026-04-14 01:35:53'),(66,'App\\Models\\User','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','login_success',NULL,NULL,'[]','[]','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','auth,outcome:success','2026-04-14 01:39:30','2026-04-14 01:39:30'),(67,'App\\Models\\User','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','dashboard_trends_view_requested',NULL,NULL,'[]','{\"metric\":\"submission_count\",\"group_by\":\"day\"}','http://localhost/user/dashboard','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','reporting,resource:dashboard_trends,outcome:success','2026-04-14 01:39:33','2026-04-14 01:39:33'),(68,'App\\Models\\User','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','audit_log_exported',NULL,NULL,'[]','{\"filters\":{\"from\":\"2026-04-11\",\"to\":\"2026-04-14\",\"sort\":\"desc\"}}','http://localhost/admin/audit-log/export.csv?from=2026-04-11&preset_range=72h&sort=desc&to=2026-04-14','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','audit,outcome:success','2026-04-14 01:59:09','2026-04-14 01:59:09'),(69,'App\\Models\\User','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','admin_report_deleted',NULL,NULL,'[]','{\"report_id\":\"fab5dacf-032a-40e1-8fe3-f205ef5550b7\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','admin,resource:report,outcome:success','2026-04-14 02:09:51','2026-04-14 02:09:51'),(70,'App\\Models\\User','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','admin_database_backup_created',NULL,NULL,'[]','{\"backup_file\":\"db-backups\\/20260414_021925_test-backup.json\",\"backup_label\":\"Test Backup\"}','http://localhost/livewire/update','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','admin,resource:database_backup,outcome:success','2026-04-14 02:19:26','2026-04-14 02:19:26');
/*!40000 ALTER TABLE `audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_credentials`
--

DROP TABLE IF EXISTS `authentication_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication_credentials` (
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  CONSTRAINT `authentication_credentials_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_credentials`
--

LOCK TABLES `authentication_credentials` WRITE;
/*!40000 ALTER TABLE `authentication_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboards`
--

DROP TABLE IF EXISTS `dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboards` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboards_account_id_foreign` (`account_id`),
  CONSTRAINT `dashboards_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboards`
--

LOCK TABLES `dashboards` WRITE;
/*!40000 ALTER TABLE `dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_fields`
--

DROP TABLE IF EXISTS `form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_fields` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_template_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_type` enum('Text','Number','Date','RadioButton','Checkbox') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `validation_rules` json DEFAULT NULL,
  `goal_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `options` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_fields_form_template_id_foreign` (`form_template_id`),
  CONSTRAINT `form_fields_form_template_id_foreign` FOREIGN KEY (`form_template_id`) REFERENCES `form_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_fields`
--

LOCK TABLES `form_fields` WRITE;
/*!40000 ALTER TABLE `form_fields` DISABLE KEYS */;
INSERT INTO `form_fields` VALUES ('079e919f-f138-4214-8c13-4b1fb6272c82','731ca72a-99bb-41bf-afa2-890d8059c965','Heart Rate',NULL,'Number','[\"required\", \"integer\", \"min:0\"]',0,NULL),('18b776a5-5889-40d4-a82b-3074a6ac62ac','731ca72a-99bb-41bf-afa2-890d8059c965','Meals Per Day',NULL,'Number','[\"required\", \"integer\", \"min:0\"]',0,NULL),('428de7aa-6ef4-44ca-93d0-7c14ed7c9ffd','5ea4524f-6139-41b5-a480-b2807dd78f70','Full Name',NULL,'Text','[\"required\", \"string\", \"max:255\"]',0,NULL),('5cbdef5a-d42d-4f84-864d-b73c12950a53','8cd78c30-7515-4c2a-9fbf-55f524d602db','Button Work',NULL,'RadioButton','[\"required\"]',0,'[\"yes\", \"maybe\", \"no\"]'),('61b65f92-25da-458a-a978-512ef0d031a6','5ea4524f-6139-41b5-a480-b2807dd78f70','Email Address',NULL,'Text','[\"required\", \"email\"]',0,NULL),('703c8e3a-67e6-465e-b90d-576f3ed13834','8cd78c30-7515-4c2a-9fbf-55f524d602db','Full Name',NULL,'Text','[\"required\", \"string\", \"max:255\"]',0,NULL),('70752a0e-6f65-4210-a627-5c2438d0fabd','4d3e4662-412e-4552-a386-6a7abf29048e','Age',NULL,'Number','[\"required\", \"integer\", \"min:0\"]',0,NULL),('7ecf99c5-5556-4854-9fce-03b446d6c4c9','8cd78c30-7515-4c2a-9fbf-55f524d602db','Email Address',NULL,'Text','[\"required\", \"email\"]',0,NULL),('8a08ada4-c01f-4957-8a58-c7aea05d5a78','f1338c46-4c14-47ee-9e34-7b8f528216d3','Email Address',NULL,'Text','[\"required\", \"email\"]',0,NULL),('9bdf0576-1968-4028-aa39-e18524d6ac54','5ea4524f-6139-41b5-a480-b2807dd78f70','Preferences',NULL,'Checkbox','[\"required\"]',0,'[\"Option A\", \"Option B\", \"Option C\"]'),('b782ec36-cfe7-4dcf-b57b-ff32d2e72d07','f1338c46-4c14-47ee-9e34-7b8f528216d3','Full Name',NULL,'Text','[\"required\", \"string\", \"max:255\"]',0,NULL),('d322bde9-698b-4b8e-8fe7-ce4d2039f5fa','8d074b61-0c8c-40cf-a560-43a328e0f727','Appointment Date',NULL,'Date','[\"required\"]',0,NULL),('da946f1e-4a36-4e32-a0e6-4537afe230b8','731ca72a-99bb-41bf-afa2-890d8059c965','Weight',NULL,'Number','[\"required\", \"integer\", \"min:0\"]',0,NULL);
/*!40000 ALTER TABLE `form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_submissions`
--

DROP TABLE IF EXISTS `form_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_submissions` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `form_template_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('SUBMITTED','FLAGGED','APPROVED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `form_submissions_form_template_id_foreign` (`form_template_id`),
  KEY `form_submissions_submitted_at_index` (`submitted_at`),
  KEY `form_submissions_account_id_submitted_at_index` (`account_id`,`submitted_at`),
  KEY `form_submissions_account_id_form_template_id_submitted_at_index` (`account_id`,`form_template_id`,`submitted_at`),
  CONSTRAINT `form_submissions_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `form_submissions_form_template_id_foreign` FOREIGN KEY (`form_template_id`) REFERENCES `form_templates` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_submissions`
--

LOCK TABLES `form_submissions` WRITE;
/*!40000 ALTER TABLE `form_submissions` DISABLE KEYS */;
INSERT INTO `form_submissions` VALUES ('00ca8510-9f8a-40af-8c36-9f9626520dab','e23f917d-388f-4bcf-bbd3-1b55e2fc0805','7b84eef3-0c81-43e9-8815-2426a77e6a4b','SUBMITTED','2026-04-12 23:21:11'),('09f52cf3-8076-4559-b48f-b0336f4cd826','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-02 10:00:00'),('0cccf81b-80a7-4112-b4d9-b6d5ac7e1ecf','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('0d59ff4e-5149-41e1-841a-80f2d8a4922b','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','4b203b36-7d8c-444b-a187-51052e68492d','SUBMITTED','2026-04-12 23:21:10'),('0daa853a-2aa4-470f-8285-0d7e2090d36d','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 02:31:51'),('10c02a45-7dff-4458-9473-9d1af83a908c','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('1776b150-4ff6-4ddf-ae24-f5f90da68c19','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('18598738-ecf0-4d67-a54c-42ef2c527ab1','3467c3ce-47fb-407e-b44c-2deef72f4747','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 23:21:10'),('2104b7a5-6e5b-430f-872d-751737601993','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-04 10:00:00'),('302c7869-2628-4a6b-b2cd-e2899905e0a7','600197de-bdf8-4a97-9238-53d514debc2e','2abca6cc-9b82-4152-85b1-396f331b87ee','SUBMITTED','2026-04-12 23:21:10'),('32bf5ac9-3863-491b-b29d-919bd6679e9b','051f76f1-0e9b-467c-b8e8-f1ededdffcf1','51c66f84-dd6c-46c4-ab68-df71edfbd4e4','SUBMITTED','2026-04-12 23:21:10'),('336cc250-4273-47d9-9b85-05030e68ee7d','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('3e75def6-7181-453a-a1c9-d07fa933431c','0cc3c479-07f2-4a67-93ac-7866b238daeb','162ce28a-0cc0-452e-8dd2-48bfa413cbf9','SUBMITTED','2026-04-12 23:21:10'),('3fdaf572-bfce-418c-a71f-1a75cc35217c','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('44f6a4ab-3204-4653-9c4e-75143c2f5272','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-01 10:00:00'),('4624f16a-300a-4939-9fb2-817ddf491980','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('490508cf-208f-49d9-ba20-327aae821b73','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('49064f83-c450-4992-8c1c-5a50cf4e5495','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 02:31:56'),('4b1e733a-d7ab-46c3-91f0-6dcd647813bc','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','4e5bee2b-efc0-4436-86be-77cb067beb4b','SUBMITTED','2026-04-12 23:21:10'),('4c358a45-b579-4740-9782-1436c29fd555','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('501ffed1-15ec-403a-a443-e58bfa10d1f0','817e9947-0a90-45e8-9dd0-d1e7de1e443c','ca826a84-4853-4b3c-8092-f4de424703ed','SUBMITTED','2026-04-12 23:21:11'),('56040d44-d1df-432e-8fee-a3636b37f39f','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 02:32:11'),('5f3b1835-a60a-48a5-aefd-636705934888','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('6190ee4b-00c0-40c5-95a4-8ddb7f54a7cf','7c28e0f1-d0e6-4422-a7be-563b3363bcfa','968284d3-dcae-4972-9764-63b9cdc2d728','SUBMITTED','2026-04-12 23:21:10'),('646c47f2-fd92-479c-a337-70863e7a28b5','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-03 10:00:00'),('652de4f6-38b3-45f0-9cc2-de957e06a80e','051f76f1-0e9b-467c-b8e8-f1ededdffcf1','a8d7b872-f947-4c99-9206-becc252b5992','SUBMITTED','2026-04-12 23:21:10'),('69b3021a-5a58-4f4b-8fbb-230b3db3143d','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('6b8cacfb-94dd-4b27-be87-b6b6ffa822b6','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('700045c9-73c0-44df-b5ad-15cec6eac37c','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('724bd9ef-ebe3-444d-99db-04aa59e4cb1a','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('74f5d7b3-963e-40b6-92df-98d309de368d','c98b30fa-2642-4778-9e81-78bee05a62ec','c39f8807-6e70-4498-be68-8d59453b0704','SUBMITTED','2026-04-12 23:21:10'),('7618c5e8-e605-4a8a-8c79-42242253261d','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('79f6537f-ec0f-4942-ba96-d37cfa8a587f','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('81185fbf-fdde-4d28-a420-ef485d9155ab','3467c3ce-47fb-407e-b44c-2deef72f4747','0fda7caf-2a82-4c26-8173-b31b56ff66bc','SUBMITTED','2026-04-12 23:21:10'),('84f45d70-5888-4fae-93ee-9923d6067cae','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 02:32:00'),('88f9a56f-56a8-4b79-81b8-f7e0860aa334','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('8d86c137-3b38-40a6-9c72-c1f64818ff12','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('8ec7ab9a-64ab-4386-908d-c384084a7542','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('907a8e1a-38b3-4cb1-bca9-6bd2ad0b3c3e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('923fc9e0-592a-4eca-8017-557f72129c14','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('93f27c80-1049-44a4-ac31-52823c27ffb5','7c28e0f1-d0e6-4422-a7be-563b3363bcfa','9c3e4496-db11-48e1-ba8b-8296c10a111e','SUBMITTED','2026-04-12 23:21:10'),('98990b01-761f-4890-a75e-75828b816d86','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','20f3025a-c0c3-4118-81c4-540002e90350','SUBMITTED','2026-04-12 23:21:10'),('9c0119f1-a90f-4347-ac05-bd1a5458e556','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('9e1e3021-412c-42b3-ab3e-d94fbe7d15a6','817e9947-0a90-45e8-9dd0-d1e7de1e443c','41a1e296-98d1-49cc-94e5-98d9e0ec8909','SUBMITTED','2026-04-12 23:21:11'),('9e470088-b1bc-4df8-a95a-5db5ecdad6c1','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('9e9d28ed-162d-4909-bf2e-a0f0ea1561a8','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-05 10:00:00'),('9f10eee1-c964-452c-a0c9-78835873072e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('a9f70025-972e-475c-81d7-820c59c71759','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 02:31:38'),('ae501da3-65fd-454d-8b96-de67209aa5fa','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('af4fb0c5-08b6-4b01-8eba-833eccc3253c','c98b30fa-2642-4778-9e81-78bee05a62ec','670eb3b7-bea3-4c0e-b11b-f885ab370077','SUBMITTED','2026-04-12 23:21:10'),('b0e0d8d1-6d67-485b-8b15-daf2a5bd666e','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('b6281632-4967-46f3-a2a3-e4e6986209ae','0cc3c479-07f2-4a67-93ac-7866b238daeb','f79d0e0b-d589-4b7d-9c28-9bbe160ce428','SUBMITTED','2026-04-12 23:21:10'),('b6570321-425e-4d7e-8e54-81970f18b67e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('b6c964a8-c31c-4584-ac0a-cce3d2ad19f7','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-09 10:00:00'),('bb189117-5055-4455-ae8a-5a26b6e6f196','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('be31b25a-50ae-4696-8ea7-25bd58d94d48','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('bfb8e64f-830d-4297-a0d7-e4c7d42ff4b3','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 02:31:44'),('ca6e1fa4-ae06-48c1-8e08-ddaef355babf','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('cb2ba0d0-8f91-460c-af12-f31d13693c6b','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('cc7481ce-5305-49db-a849-c25e50fc898e','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','d28fb189-afed-4613-a9a2-33e377cf9856','SUBMITTED','2026-04-12 23:21:11'),('ccbff68c-1091-42eb-ab10-d313f8707a17','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('cd1b1590-c671-410c-a6f1-233412dba2c7','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00'),('ce1f9bf6-87d9-4de6-9322-df624fe408e1','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('d1601afa-b62d-433e-9410-fd0fee15bd04','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 02:32:05'),('d2aeb557-48c4-4aaf-9380-b57f6627fd40','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('dafd98b4-0e35-4b5e-84cd-33226700eb4e','600197de-bdf8-4a97-9238-53d514debc2e','135c9ffd-881b-43ad-853b-4428190b6c80','SUBMITTED','2026-04-12 23:21:10'),('db5b47ee-5cf1-4e08-8354-da5eeacddf24','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('e0228b73-0f73-467e-a7a8-3b8e578e36fe','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('e600a719-2021-4347-91ab-39c68a06dd77','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-06 10:00:00'),('e839bbec-a2e7-4bfa-9ffb-420baaa21295','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('e9558525-55d8-42b9-9182-eaefc52617c3','e23f917d-388f-4bcf-bbd3-1b55e2fc0805','31ada70f-2c2d-4153-beca-ed2ec861e98e','SUBMITTED','2026-04-12 23:21:11'),('ea0da990-6b63-4c84-8070-4b31034bde38','9929bc57-d157-467a-9d9c-24b56a6863e9','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('eb82f85e-7171-4440-84b9-217567327648','32586ad1-7956-476e-b341-c72682de18dc','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('ebb46a57-c03c-4395-8f09-ab5e37c0e21f','fb04e079-f2c1-45b1-9733-71aa5e52896c','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('f410fc5e-18b8-47ed-b7c2-48bc61e70c2a','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-08 10:00:00'),('f5b58bed-e8f8-4936-af75-971284456bda','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-07 10:00:00'),('f8288fa9-07fa-469f-8dde-a93508e50230','e7e74f59-fd88-47f2-8de8-bf345109b9e9','731ca72a-99bb-41bf-afa2-890d8059c965','SUBMITTED','2026-04-07 10:00:00'),('f9b72071-2375-41d9-983d-9727eff534b1','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-12 10:00:00'),('fa38dfea-ab98-4699-a9cc-32f1568ab3c2','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-11 10:00:00'),('fc3efd13-84a9-4688-8e29-19ddc178f3d4','9209c193-fa25-432f-85e5-96e96ade32ed','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-13 10:00:00'),('fe102f39-96af-4c21-b59f-bf0387692436','699950d5-86ca-44ec-9473-e64f5659b004','0c92a5c6-c652-4289-a362-d2db718ff1d8','SUBMITTED','2026-04-10 10:00:00');
/*!40000 ALTER TABLE `form_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_template_versions`
--

DROP TABLE IF EXISTS `form_template_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_template_versions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `form_template_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema` json NOT NULL,
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_template_versions_form_template_id_foreign` (`form_template_id`),
  KEY `form_template_versions_created_by_foreign` (`created_by`),
  CONSTRAINT `form_template_versions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `form_template_versions_form_template_id_foreign` FOREIGN KEY (`form_template_id`) REFERENCES `form_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_template_versions`
--

LOCK TABLES `form_template_versions` WRITE;
/*!40000 ALTER TABLE `form_template_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_template_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_templates`
--

DROP TABLE IF EXISTS `form_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_templates` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema` json NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `purpose` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `version` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `approval_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `form_templates_slug_unique` (`slug`),
  KEY `form_templates_approved_by_foreign` (`approved_by`),
  CONSTRAINT `form_templates_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_templates`
--

LOCK TABLES `form_templates` WRITE;
/*!40000 ALTER TABLE `form_templates` DISABLE KEYS */;
INSERT INTO `form_templates` VALUES ('0c92a5c6-c652-4289-a362-d2db718ff1d8','ad et','{\"fields\": [\"bp\"]}','ad-et',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('0fda7caf-2a82-4c26-8173-b31b56ff66bc','officiis dolor','{\"fields\": [\"bp\"]}','officiis-dolor',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('135c9ffd-881b-43ad-853b-4428190b6c80','sunt aliquam','{\"fields\": [\"bp\"]}','sunt-aliquam',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('162ce28a-0cc0-452e-8dd2-48bfa413cbf9','in ducimus','{\"fields\": [\"bp\"]}','in-ducimus',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('20f3025a-c0c3-4118-81c4-540002e90350','fuga consequuntur','{\"fields\": [\"bp\"]}','fuga-consequuntur',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('2abca6cc-9b82-4152-85b1-396f331b87ee','dolorem est','{\"fields\": [\"bp\"]}','dolorem-est',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('31ada70f-2c2d-4153-beca-ed2ec861e98e','omnis quibusdam','{\"fields\": [\"bp\"]}','omnis-quibusdam',NULL,NULL,1,'2026-04-12 23:21:11','2026-04-12 23:21:11','pending',NULL,NULL,NULL),('41a1e296-98d1-49cc-94e5-98d9e0ec8909','consequatur accusamus','{\"fields\": [\"bp\"]}','consequatur-accusamus',NULL,NULL,1,'2026-04-12 23:21:11','2026-04-12 23:21:11','pending',NULL,NULL,NULL),('4b203b36-7d8c-444b-a187-51052e68492d','voluptas quia','{\"fields\": [\"bp\"]}','voluptas-quia',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('4d3e4662-412e-4552-a386-6a7abf29048e','Number Form','\"{}\"','number-form','for testing number input',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('4e5bee2b-efc0-4436-86be-77cb067beb4b','excepturi debitis','{\"fields\": [\"bp\"]}','excepturi-debitis',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('51c66f84-dd6c-46c4-ab68-df71edfbd4e4','sit nobis','{\"fields\": [\"bp\"]}','sit-nobis',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('5ea4524f-6139-41b5-a480-b2807dd78f70','Checkbox Form','\"{}\"','checkbox-form','for testing checkbox options',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('670eb3b7-bea3-4c0e-b11b-f885ab370077','a voluptas','{\"fields\": [\"bp\"]}','a-voluptas',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('731ca72a-99bb-41bf-afa2-890d8059c965','Test Template','\"{}\"','test-template','for testing',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('7b84eef3-0c81-43e9-8815-2426a77e6a4b','quia sed','{\"fields\": [\"bp\"]}','quia-sed',NULL,NULL,1,'2026-04-12 23:21:11','2026-04-12 23:21:11','pending',NULL,NULL,NULL),('8cd78c30-7515-4c2a-9fbf-55f524d602db','Radio Form','\"{}\"','radio-form','for testing radio button',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('8d074b61-0c8c-40cf-a560-43a328e0f727','Date Form','\"{}\"','date-form','for testing date input',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('968284d3-dcae-4972-9764-63b9cdc2d728','voluptas fugit','{\"fields\": [\"bp\"]}','voluptas-fugit',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('9c3e4496-db11-48e1-ba8b-8296c10a111e','aut officiis','{\"fields\": [\"bp\"]}','aut-officiis',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('a8d7b872-f947-4c99-9206-becc252b5992','et quam','{\"fields\": [\"bp\"]}','et-quam',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('c39f8807-6e70-4498-be68-8d59453b0704','nobis neque','{\"fields\": [\"bp\"]}','nobis-neque',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL),('ca826a84-4853-4b3c-8092-f4de424703ed','necessitatibus non','{\"fields\": [\"bp\"]}','necessitatibus-non',NULL,NULL,1,'2026-04-12 23:21:11','2026-04-12 23:21:11','pending',NULL,NULL,NULL),('d28fb189-afed-4613-a9a2-33e377cf9856','et eaque','{\"fields\": [\"bp\"]}','et-eaque',NULL,NULL,1,'2026-04-12 23:21:11','2026-04-12 23:21:11','pending',NULL,NULL,NULL),('f1338c46-4c14-47ee-9e34-7b8f528216d3','Name Form','\"{}\"','name-form','Name form for names',NULL,1,'2026-04-12 23:21:09','2026-04-12 23:21:09','approved',NULL,NULL,NULL),('f79d0e0b-d589-4b7d-9c28-9bbe160ce428','consequatur ut','{\"fields\": [\"bp\"]}','consequatur-ut',NULL,NULL,1,'2026-04-12 23:21:10','2026-04-12 23:21:10','pending',NULL,NULL,NULL);
/*!40000 ALTER TABLE `form_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `health_entries`
--

DROP TABLE IF EXISTS `health_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `health_entries` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL,
  `encrypted_values` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `health_entries_submission_id_foreign` (`submission_id`),
  KEY `health_entries_timestamp_index` (`timestamp`),
  KEY `health_entries_account_id_timestamp_index` (`account_id`,`timestamp`),
  CONSTRAINT `health_entries_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `health_entries_submission_id_foreign` FOREIGN KEY (`submission_id`) REFERENCES `form_submissions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `health_entries`
--

LOCK TABLES `health_entries` WRITE;
/*!40000 ALTER TABLE `health_entries` DISABLE KEYS */;
INSERT INTO `health_entries` VALUES ('00d6ced7-8083-4beb-83c2-ccbb0b3ef221','3e75def6-7181-453a-a1c9-d07fa933431c','0cc3c479-07f2-4a67-93ac-7866b238daeb','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6IlhXREV4eTJ4ZVcwU05kSTlJYmlXTWc9PSIsInZhbHVlIjoicWJiRWxEbWJMZkFGNnFSUjZKNkcrLytNMlZJV2M5UzlUak01Z1RFRlRYOE0zN21DUnM2dHVhejI2NTlmRkZZViIsIm1hYyI6Ijk2ZWZkOTdlOWVmMGFhODgwM2ZlMTk3ZDg4ZWU5MWIxMDI0OWQ0ZjYxOWQ1M2ExZGIyZThlMDFhODUzZTZkNjAiLCJ0YWciOiIifQ==\"}'),('028038ce-c3b7-4e3a-a5dc-e69940c8071c','fe102f39-96af-4c21-b59f-bf0387692436','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IkZjT1JNOHZMaUdDNmdiZzZFSmxYbUE9PSIsInZhbHVlIjoiaERyWEY1aHoyTm0rUWhBZHdUNGdvd01LQllHWFlyaER0Nm8vcmo5a0E2TT0iLCJtYWMiOiIyZDQ4MTc3NGM5ZDFlNzJjYmY1NDU2YzM5YWMxYWJmNTY3NzJmZmM4ZTk0ODk3ZjAxOWM1NzVhMDg2ZjEzNzViIiwidGFnIjoiIn0=\"}'),('089f5144-6de7-4e05-9614-2ad8a9adc5db','490508cf-208f-49d9-ba20-327aae821b73','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6IlNxQWc4bjBOL0NPaURuTTdvUVlsSlE9PSIsInZhbHVlIjoiUUltcExDTWZUZTFCZ053amZ1Y0lVOFFOdENRRElJdUtEK2d6WnlpM2c2ND0iLCJtYWMiOiI3MjM0OWY5ODUxZDkwZWMyMDQyNjc4YmNjNDFlZDlhYjEwY2EzZTNmMDRkMWRkZjc1M2YxYWQ3MWI0ZDg0NTIzIiwidGFnIjoiIn0=\"}'),('09c7a22e-a17f-4a52-b9e2-e0f6971f0a23','32bf5ac9-3863-491b-b29d-919bd6679e9b','051f76f1-0e9b-467c-b8e8-f1ededdffcf1','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6Imlzb2xiMUYwWFdtdkxMZDRPdVlBY1E9PSIsInZhbHVlIjoicWx3VEFWb2hPcWttRFVZWWlSYkh0MzQvVVNHY0JHdkczbEMwNWNVNXpOWFdwTmxEb0dpRGlZT05tY3hxZGZJcyIsIm1hYyI6ImMxNTIzNmFkNmQyNGVlODY5NGJiNDIyYzM1MDY0NjdhYjc2Y2JhYjM0MjMyNjZhNmExNWM5MWU4YTMxODFlZTUiLCJ0YWciOiIifQ==\"}'),('10650388-4270-49a3-b482-ff7b542311af','49064f83-c450-4992-8c1c-5a50cf4e5495','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-10 02:31:56','{\"data\": \"eyJpdiI6ImdTTEJETXpLejBSVkVlN1p2UExWTmc9PSIsInZhbHVlIjoiS0V2dVdnUHA1dllURWFaSi9ZWUF4dXNCUzlER2piR2xkL3lGYjI3cXJBTT0iLCJtYWMiOiJjYzY5NTJjMjlkMWUwN2Y1OGUyNDIxZWRkMTQ5MDk1N2I0ODA0ZGFjNzk4ODNmZDY4ZGNjZmEzY2E2YzY0MDk3IiwidGFnIjoiIn0=\"}'),('10dd74f1-71a9-4d09-966b-4d4b6daf9a0a','eb82f85e-7171-4440-84b9-217567327648','32586ad1-7956-476e-b341-c72682de18dc','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6InExeVJjbE5sRjh5YWQ5M3lEandIbVE9PSIsInZhbHVlIjoiUy84c1AwbEdkTmlENjJCb1gweFlkSFFLdXkvU01ndWR6ZGRuQzR5alZ0az0iLCJtYWMiOiI1MzdlZTI4NDQyODNhMTNmNzU4YzRkN2FlNDlhYmJmOGUyM2UxYmQ2OWI5YzVhZmQ5YWI1YzRhMDc3Y2YzMTI3IiwidGFnIjoiIn0=\"}'),('15bad47d-6215-41c2-85fd-a4e2a29195fd','ae501da3-65fd-454d-8b96-de67209aa5fa','32586ad1-7956-476e-b341-c72682de18dc','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6Imk4UVg2VjJrRW1sdTBPMWt3dUNIQ0E9PSIsInZhbHVlIjoiaW8zWTIzYit0TncrU3FTWDk2K3JPZ051V1k1QTRFV1MyYXdaUkhQb0sxZz0iLCJtYWMiOiI5OWE2MzViZTAxMmM2ZjUwMDM2MjA4MjcxNTFkMjcyMTIxNWRlNGVkYmRiYTE0Njg0ZjM0OWYyMTQxNzA2MGU3IiwidGFnIjoiIn0=\"}'),('17236a4d-609d-4fe6-8820-035f8fc6d9ad','6190ee4b-00c0-40c5-95a4-8ddb7f54a7cf','7c28e0f1-d0e6-4422-a7be-563b3363bcfa','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Ik5UVE9tc2JFYUs1bWROa1kvV0o5WUE9PSIsInZhbHVlIjoiZk1WYStLbVJIWjRMQndxV09WT3RNenZxVlFvWDhTaTRZcktnc29BZVlTWTFiOUJidVpJWVlnZmpwSkF5TmhRayIsIm1hYyI6Ijk0ZjA2OThkYTIzMzk3YzVhZDVmYjMzNTk5NjBlZDFiNDA0OWYzYmE4NWI3YzY2ZmQ5OTI5MTY2YTMxNWRjMTAiLCJ0YWciOiIifQ==\"}'),('18f51415-1728-4ad7-850e-41df4c6a7ced','69b3021a-5a58-4f4b-8fbb-230b3db3143d','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6IjFTZlk3MkxlZllJc3BDQVhVNG9Pb3c9PSIsInZhbHVlIjoiUE05R1VBSEJNa3RUS0RwZXJ6WXFQeTd6ZkM3Z1VuZ2FSSjAxSHhhTk5Taz0iLCJtYWMiOiJhNzFjYzRlNGYyNTkzMDcxNzNkYjU2YjRhZjg4ZjNkNTU5NWU3NWVhZTY0MTQ0MmY2ZDUxYWMyMmM0NTEyMjlhIiwidGFnIjoiIn0=\"}'),('1ac1d065-e556-47e7-b9d6-21ab078c6ffb','e600a719-2021-4347-91ab-39c68a06dd77','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-06 10:00:00','{\"data\": \"eyJpdiI6IitsNjQ2eGtMSkdjQmllQkc1QnMvRFE9PSIsInZhbHVlIjoiaS9sZHNNb2tCSDZSQ3hDd1puaExRMkFsdXBFQTJLc2N2ZURYc01icnUvMVUxMkNDRkJBOXc2VWM0OUpXWWEyOCIsIm1hYyI6IjFhM2Q5ZmY2ZTdjYWEzOTkzZjY4YzllMTEyZGRlMTVlMDJmYTZiYjc1OTBkNTZjNjJlYjE2ZGIzZjI2NDgyYmYiLCJ0YWciOiIifQ==\"}'),('1c529e0b-68a9-4a7f-bf6f-f5258f8fb80b','9f10eee1-c964-452c-a0c9-78835873072e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IlRMWWdZRGc4bWJieUp4OVkxNW1WakE9PSIsInZhbHVlIjoibTMrS3RMK2c3MWJpQkprYVhmL010Kys4TUJ1SmFMWm5nMXg5Y201ZDdEcz0iLCJtYWMiOiJhZTQ5YjViOTNlODYyYjg2ODhmNWU4NGEwZDI4Njc5NTkyNTQ5NzA2M2IzZDk3MTdhZTU3NTkyOWM2OGQ2NmU3IiwidGFnIjoiIn0=\"}'),('20d32b85-ec83-43fb-a5a7-9c7730cc3b24','ccbff68c-1091-42eb-ab10-d313f8707a17','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6IittSWNmTUF4YVFYNzhZbnRHMEV6RHc9PSIsInZhbHVlIjoia3ZsN1E1eUl6WE1vamNyYUs2cVZKeVdyQnF5NSsySlgrRTgyK1ZDU2lhWT0iLCJtYWMiOiJlMDY3MTBjM2JmMWU1ZjVkYmUxYjViY2JiNTU5YWRiMjU1OWEzOTUzM2U1ZDQzMWQ1YmI3MzMwMmJlOTllOTM1IiwidGFnIjoiIn0=\"}'),('24ed2356-3007-43c4-9233-57ca8b85334b','00ca8510-9f8a-40af-8c36-9f9626520dab','e23f917d-388f-4bcf-bbd3-1b55e2fc0805','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6ImtiNXpqQnFOeXlLSjJqT2p3KzlJYkE9PSIsInZhbHVlIjoiL1BRajdqdXFVNWFPczhHUGIrK0N6UzhmRko4V3R0Q25ZZlpQcnFHWG15eFc4VHRMTnBRaDdlc2orc2YzcEhsOCIsIm1hYyI6IjFhZTQ3M2I0MzBhMjMyNzI0ZWViY2QxZGM2YmY3NmZjYjczNjYwODAyODE3MTNiYTg2NGYyNWE2YzJhOTQ3YjQiLCJ0YWciOiIifQ==\"}'),('26fd9934-e969-4d78-87a1-9d0090f138aa','4624f16a-300a-4939-9fb2-817ddf491980','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6IlNDRUNtaDhPempSK3Y3YmlEa2c2OHc9PSIsInZhbHVlIjoiSDhtM1hOYW9SNkpXdkVwZ3NKMjhwd0FIUFZKa3RQM2ZmYzB3bnc2SmNTdz0iLCJtYWMiOiJiNmI5NmMwODRlN2NhYWJlYWZlZjcxMjNkMGI2ZDJlNjA4NDEzMjViODA2ZDYwZDlmYTU1MGE1NGI1Y2FlMDNjIiwidGFnIjoiIn0=\"}'),('302a4784-43cb-40e3-a307-444f7df77d4f','44f6a4ab-3204-4653-9c4e-75143c2f5272','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-01 10:00:00','{\"data\": \"eyJpdiI6IjFhbUtXNzAveWdHZjRsZU9RZHBPV2c9PSIsInZhbHVlIjoiTjhLTkZML2x3TDAxMnNLOENkSnY5S1JodUFvdkRpWndEMzlONUd2SFlvRkVDekQrcFhhZDgrOEthNnNsYk9ETyIsIm1hYyI6ImFmYzI1MTM4MzQ4ZmI5ODgzOWU1NDg2NzFjMTEzYzI3YTc4NzBlNjg3MzRjZWYyZTE3MjQ0ZjMxOThlOTVhN2MiLCJ0YWciOiIifQ==\"}'),('3571c8ea-238f-4727-b776-446d990a6941','ebb46a57-c03c-4395-8f09-ab5e37c0e21f','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6ImM2YU1rd0cyNkpSY0Z0S3hxV2RWVWc9PSIsInZhbHVlIjoiYmQyVDgvTkp5TDFhK3g3Qyszcm03RUF3MGFDSUVibmhQbGVOUXNIckMvST0iLCJtYWMiOiI2NWE2NTkyODkzNmViMTU1MGNlOGU0ODdiYTU0NDVlMTg3ZWZhODZmZjA0MTJmM2RjYmQ5NTNlODI4NzU1ZmE1IiwidGFnIjoiIn0=\"}'),('36bfd242-efdd-46c8-a47f-969c980e8b3b','79f6537f-ec0f-4942-ba96-d37cfa8a587f','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6IjY1aEtHS3pkTFBzMkI0NGpSV2RZdkE9PSIsInZhbHVlIjoiZ0Q4eThybFJMdkZ3N2ZvNzNlSWdBcFNJdStIVjVwMlo0OUVzSS9SNXJaST0iLCJtYWMiOiJlNGJlYWI2NWYxNzEzMWEzMGQyM2MwNzBjZGIxMDg4MTA0ZWU5YzQ2Njk5ODRhZTllYjU3ZWFmMWVmMmI3N2M5IiwidGFnIjoiIn0=\"}'),('397fec97-b2a2-456b-93af-fa15b85ecdda','9e9d28ed-162d-4909-bf2e-a0f0ea1561a8','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-05 10:00:00','{\"data\": \"eyJpdiI6InFpRnJsVVBhVjR5TlROdS85TFJkaXc9PSIsInZhbHVlIjoia2JkOVlKcEtSVWpLQjNpdFdTRE44VzJia2F4SGRQSVJwMVUrcDlOak9QcGdCSkMzRVFZQno4eE9IS2ExMkJlOCIsIm1hYyI6IjRiZDczMjQ1NzdlMTIxNmIyNjJiNzRhYjBjNjBhYzI3NzdiZTVlNTgwODRjYjgwYTNjZjY1YzEwNzQ3NmMyYjAiLCJ0YWciOiIifQ==\"}'),('3c4edfb9-bd67-4946-aaf8-77cefbed26c6','e9558525-55d8-42b9-9182-eaefc52617c3','e23f917d-388f-4bcf-bbd3-1b55e2fc0805','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Ii9kUnYyZmJqZzkzWDlRTnJpb25ablE9PSIsInZhbHVlIjoiZUZINU4yUStMZkhhaWtVS1RoWjhrMHg5NFkxZTBySy9wMm5WaEtGZllBS05GVER5Smt0aTMrKzFGVkE5Z3FFVyIsIm1hYyI6Ijg2ZjIzM2IxY2I1ZGZkMjhhZmVlOTdhN2Y4ODAzOGU3ZDI0ZTdjMzMxMDIyZDc2ZDlhM2I5ZmJkY2IwMWQyNmMiLCJ0YWciOiIifQ==\"}'),('40b39830-4a47-4e75-91a7-07a53507f377','56040d44-d1df-432e-8fee-a3636b37f39f','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-13 02:32:11','{\"data\": \"eyJpdiI6ImltRXRxenQyNEo2S0xFYVpnK2NGdkE9PSIsInZhbHVlIjoiSjhKVkNpcXg4QXliUEVURWNzRGlvdTZvTzJYNHRMNFZNeHdaenJIVzFSQT0iLCJtYWMiOiJlMjYwY2M4MWExMjhhNWY4N2MxMjcyYjQ4MzkyMjY1NTkyYjA2MmZiZGNhYWE5NDFmZDAwZDMwNjA0YzcxNmNmIiwidGFnIjoiIn0=\"}'),('41c57784-c538-4d68-a00d-60083103ae56','93f27c80-1049-44a4-ac31-52823c27ffb5','7c28e0f1-d0e6-4422-a7be-563b3363bcfa','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6IjJOZTRUTWFvcm9ZZmIxcVhHZUpKL1E9PSIsInZhbHVlIjoid1JWRzlzNmtDQ01qRHRUWXdvMkRZUU5oV29nOFE0ZkFwa25vWEhpMnV3VjVLaVlsT1pqVzR2ODVOYnNYY3hjMCIsIm1hYyI6ImIzMzA3ZmEzMGJjMzA5MjM0Y2MzNDIzOWE2MmUwNjg3ZjgzZWFlYmUzMmI4YzY2MzRlMGM3ZDI1MDJkYmVjMmYiLCJ0YWciOiIifQ==\"}'),('43aaeaec-f0f9-4f6d-b466-468b9dc942b9','fc3efd13-84a9-4688-8e29-19ddc178f3d4','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6Ik5GS2wvVUVDdlh6enJXdC9yclIyQ1E9PSIsInZhbHVlIjoieDVjeGNQcS9rZnR6TGhQd21CRGxSTzQrQmNIbCtZejNqNkdiYm51ME5vRT0iLCJtYWMiOiI0OTVkZjg4OTY4MzNhMTdiNjgyNjU4YzhiMWY2MzNkMWMzOTU5MDQ4NjVlZWI0MGMwOTBjY2M2Y2ZkMjFlZDE3IiwidGFnIjoiIn0=\"}'),('468802c3-addf-4683-ace2-d20a73f78e2e','ce1f9bf6-87d9-4de6-9322-df624fe408e1','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6IkdaVVZFYUR1emUzZFJuQ2k0VDMwc0E9PSIsInZhbHVlIjoiQWNHdTZVcXdXNnRzS0lyR0pNd3AxZVE2QU1qWDcwTmo4bGcxdFFRVGRGRT0iLCJtYWMiOiI5NmFmNTYxOTQxNmUxYzRhYzRhNWExZWIxZjVmMjhmN2ExZDEyZjQxYzRmYjkxNTlhZjVhMDNkMzdhMmY0YThlIiwidGFnIjoiIn0=\"}'),('4a878b39-2393-4482-8828-227e1cf98812','923fc9e0-592a-4eca-8017-557f72129c14','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6InRiNDBoU3pHbHFTTXJONFZRVVRDSnc9PSIsInZhbHVlIjoiRDZkRGE0SlpLT2Vzb2x5VlZYbnRVZ01DWnZ2dEpPWmp1bWhSZlFxTGE0OD0iLCJtYWMiOiI5OTRlZGYwM2YwNTk4ZWFkYWI3MzRiZThjYTQzYTRiMDU3YzM1NjA0YWNkMDAwOTFlZTMwODcwYjQyYjA0ZWE0IiwidGFnIjoiIn0=\"}'),('4c3a4987-d202-47e7-bb2e-a7e5e165d1de','88f9a56f-56a8-4b79-81b8-f7e0860aa334','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IkJ0YkVlMGxpakVlMk1GRGF0TVlZUHc9PSIsInZhbHVlIjoicm9iamtCSjZ6Q0JuR2l2QUpHTEJUblNNOTlTanRNSS90c1Y2SjE0Uk95Yz0iLCJtYWMiOiJjZDAyZmM1ZTNkNzNmZjU0ZjkwYzA3ZDYzNzQ5YzhmMzRlMmJmZjM3OWMxNzMzYTk3MzI0Nzc4NDQ2NTNiNGU0IiwidGFnIjoiIn0=\"}'),('4f4d2708-4569-48ce-8bc5-b0f1da0aad03','0daa853a-2aa4-470f-8285-0d7e2090d36d','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-09 02:31:51','{\"data\": \"eyJpdiI6InUyYThhNmIxTTh0QVRsTVhlL2Y0WHc9PSIsInZhbHVlIjoiRE5OdjdPZGpJWDVncGN5ZWRqbEtKM3ZGaHhzL1U1Rlk4RzlhNU95aU5TZz0iLCJtYWMiOiI0NTMxMGE5MGFkMzdmMmYzOTExOWExYjM1MzgxYWU2NzU1YmU1MjA1ZmMwZmQ5YjFiNzIyM2EzMjQwMmVlZDA4IiwidGFnIjoiIn0=\"}'),('4f5f079e-b910-4843-9b5f-1b1c2819bdae','f5b58bed-e8f8-4936-af75-971284456bda','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6Ii9XeGo0aUkySDVEaU80YWdELzloK0E9PSIsInZhbHVlIjoiNEtYSGpMVkVzNTQyR3JSVHBqeGhZMEJYelVqTmljTVhYSndWbWRiWEptWT0iLCJtYWMiOiI1NjY0ZDNhYWY4YzI2MGRmMGExMTZmMWZkYmNlYTc2ZGU5M2JlNTFmYzc1NzQ0OTE0ODE3ZTg4OWQ1YTgzZjc2IiwidGFnIjoiIn0=\"}'),('57fca6cf-d2fe-4ba7-8238-c9b6024008a1','5f3b1835-a60a-48a5-aefd-636705934888','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6IkxEZHBOeW14dnBQQ3JxZUVZM0toMUE9PSIsInZhbHVlIjoiMWxuNFMwbmZEcWpNM29KTVpaazFJYjRDbEN2TGZHTk5VMXBhMlRFaENLOD0iLCJtYWMiOiJlYTFiOTgyZTdjMWVlODRiOTkyMjI5N2MzNGZiMzdiMDYwZmFmNjNhNWE5YjRhY2MwYzIxOTFiMGVkYTUwZTk2IiwidGFnIjoiIn0=\"}'),('5a6bda4e-0390-4ac3-a5ba-8afc7fd58a07','74f5d7b3-963e-40b6-92df-98d309de368d','c98b30fa-2642-4778-9e81-78bee05a62ec','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6IlRub1lpR1drZHNkaUczNWF3andrWHc9PSIsInZhbHVlIjoia2RxMnBzWHFZNGpSbnVKVkt4TGZNdkdSblN5T3VqODNnRTRsNGtIVjlneFlYUFIyRVhkTXMyKzBIZDVpV041NiIsIm1hYyI6ImZmYjQwNTk1ZWExN2FlNDU5ZGJkN2QzYWRkNDg2Y2Q5MmY3ZGFjN2JhYmQ4YmU2NTVmNWFiM2E1M2VjZTFhYzMiLCJ0YWciOiIifQ==\"}'),('5ccff36a-a39e-427e-bbe0-163ca1a23011','d2aeb557-48c4-4aaf-9380-b57f6627fd40','32586ad1-7956-476e-b341-c72682de18dc','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IkVmekF2NUJrbFVPL3VQbVQrdCs4alE9PSIsInZhbHVlIjoiZVV5VE93QnRaN29iY1Zoc2xEYkt4ejl1WWZRd1h2Sk5IajhXZjc4L3E4QT0iLCJtYWMiOiIyMDlmODI4ZmZmMzQ3NTFhYzU1ZWFlZTZkZDQ2NzhjMWVlOGRkZjMxODNiOTczYmM2MjE4ZGFmYzJkZTQyOGM3IiwidGFnIjoiIn0=\"}'),('5d78e0c5-7f60-42f3-99e5-960f380594ae','652de4f6-38b3-45f0-9cc2-de957e06a80e','051f76f1-0e9b-467c-b8e8-f1ededdffcf1','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6InJHVm5iR0FXWXBCcFhUV3c0QU1vUmc9PSIsInZhbHVlIjoiUGs5enp5bTlmUUV5OE1CTmQ0TDZ6c2NEekNQVGZ4RFkrOTZiRnQ2UDBWaDRadDZMRzdyTk1rNWtDTkp4TTlQbyIsIm1hYyI6IjRkMTY2MGQwYWZlZDM5ZjdiODgzNGE4OTA2ODExNjI1MjRlMjkzNDQwOGU2ZDdlZTM2ZjY0YjlhZTI4NTg5OTIiLCJ0YWciOiIifQ==\"}'),('5db536b8-60da-4160-a0a7-083441557705','3fdaf572-bfce-418c-a71f-1a75cc35217c','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6Im5CUVdOcFNHSlRiWnhoaDVuVVF6MXc9PSIsInZhbHVlIjoiNzBuZDBuSG5KVkRYZk4vMnN5MVN3VFJPM2g4SG1ZQiswL1p4K0NvNkRKbz0iLCJtYWMiOiIxNjgzZGQ2YjZhODI5NmMxYjRkNTllMTkzZTBmZWNiZTUwN2ZmMTlkOGM4MGU0MzNlODE5NzAxZGMwMDdkZTVlIiwidGFnIjoiIn0=\"}'),('5dba8d26-3f2a-4faa-8ee0-04a90cd0a9fd','2104b7a5-6e5b-430f-872d-751737601993','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-04 10:00:00','{\"data\": \"eyJpdiI6ImJtSDQreURsYzFLeTBnZ3ZyS2hyc0E9PSIsInZhbHVlIjoidk8yR0lBL0JSVml5eWp0Z0taODZzbHgrSTJFYjZKVWc1Nm1ZTGdXclpPR3F2TlZVQlUybGt5K0lUcURGVnRZeCIsIm1hYyI6Ijg1MGIxMjk0ZTVlYzhkY2M2NDJiZDgzNmQ1ZjUxZjM3MjQzZjNlZTU2ZGYwNTk4YzM5YTkxM2I0NGQ1Y2EzY2UiLCJ0YWciOiIifQ==\"}'),('621964e9-8e7f-4fc7-b082-1bbaea538771','b6281632-4967-46f3-a2a3-e4e6986209ae','0cc3c479-07f2-4a67-93ac-7866b238daeb','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Ilpjd0VYY01qVkErL3NrbTBxdXdUWmc9PSIsInZhbHVlIjoiTm1PdEdaUHB0aUVWdzZDd2pLT25TYW9ZUThqREh0YnIyMVN2ajJBcHZ3V0JKV3RJeGlKUSt6Si9FN1cwR0NQciIsIm1hYyI6IjY3OTBiMDVlZWY1MjJkODM5NGIzN2I0ZjgxMjJlOWQxODFmY2NhNjIzNjc1YTVmNDg4NzdiZmRkNGM0ODk1OTQiLCJ0YWciOiIifQ==\"}'),('65c45904-94bd-45a1-ad2e-138032bc3d5d','501ffed1-15ec-403a-a443-e58bfa10d1f0','817e9947-0a90-45e8-9dd0-d1e7de1e443c','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6IlBhRVJQbXVvZENFVFZSYUR5T3ljakE9PSIsInZhbHVlIjoiMXVXZElwbjBXcnMvdnJaNis4MDhPM3JtOUlMYklKVHFIa0RyWTFaVjk3L0kwTjB1Q0xVNmVOMzNiL1lmOTN2dSIsIm1hYyI6IjhhM2JiZjAyYzg5MTg0MzMzNDI1OWE5MWI1MDg2MTUwMjAzZjU4Mjg0ZWJjYTVmOThiYmIxMzY5YzI1NDVhODEiLCJ0YWciOiIifQ==\"}'),('673a5c54-cbce-48c8-ae70-efce6bd50032','cc7481ce-5305-49db-a849-c25e50fc898e','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6InYxZTZlL0JyVXpsbGJkSS8rSk9oc0E9PSIsInZhbHVlIjoiYnMwb0Q0WHB1aEhyRERQaVRSM1BLSGU5WHpQWjZodWxTNVRQTzU1QlBlcFFKdzBpM1F0YmdhNXBvcmN2eVBxSyIsIm1hYyI6IjllMWQ2ZDI4NTY4NGMwNWE0N2JiMmMwMDg5MmVkZWIxYzVkNmU5MjYwY2YwZjMyZjhkMzZkYzVlYTI2ZGY3ZDgiLCJ0YWciOiIifQ==\"}'),('68200d66-e614-4d30-8f18-d244af3639ef','d1601afa-b62d-433e-9410-fd0fee15bd04','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-12 02:32:05','{\"data\": \"eyJpdiI6IjZ0dU5pekd3dGZKdXlCc1BScFg2Ync9PSIsInZhbHVlIjoiazJzZmFyZWdkeVg4TEo0YnRxbTFTMmZUOVdPWnhzS2tpZ2VZdEhSTzJtbz0iLCJtYWMiOiIxMmI4ZTMyMmU0OTljMWI1NjFlNjQyMTg2NzNjZWZhZGQ2YWE2ODNjYjk2YTI5ZDBmM2E0ZTI4MjcyMGMzYmZkIiwidGFnIjoiIn0=\"}'),('6c1347ba-202c-4758-970e-ebc1e362a0c0','ca6e1fa4-ae06-48c1-8e08-ddaef355babf','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6IklZbGJGVWFoNElBbVgwZ0tvMC85REE9PSIsInZhbHVlIjoiaXFCS09xMXVFZmZPR2hBR2Q3RTBwMnNoNUlMTmNYOGtvWVpUQlYxenZMOD0iLCJtYWMiOiI2OTI1NmI4MjVhNGJhYTcxOTQxY2UwNDA2OGY3Y2M0OTJiMGZlOTNkNDA4ZDc0MTRiM2Y3MzkzZTg0NzNlZjU1IiwidGFnIjoiIn0=\"}'),('70bff2bf-240d-46c6-b285-5dc9676703cd','0d59ff4e-5149-41e1-841a-80f2d8a4922b','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6InEwNkh3UUR4WU40TXlmVEg5MCtxcUE9PSIsInZhbHVlIjoiTVpPUVV4cnNjbzVYNCtJa3BrLzY0KzhSQzl1ZUdOWk95cVpYdno2TUJoaGtFVStIUjFOUU1GSWFOaFppYUo1TSIsIm1hYyI6IjU3N2YxY2YzOGJiYTdjZWIyMzliOGI0N2U1OGEwMzllYmE2Y2U5MDBiYjg0OWNmMzkxZTdlMzlmODEwMzc2NGIiLCJ0YWciOiIifQ==\"}'),('74a361f5-2adc-4f15-b7db-fc3edb3d3a2f','b6570321-425e-4d7e-8e54-81970f18b67e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6Im1tVmk2QUh2c3kvNitQblFnV1N2SFE9PSIsInZhbHVlIjoieHFJSUcwSWRHNEE2am5RY1RPYkpYS0FXVTVoS2s0aTZYNXZudTdweDV6TT0iLCJtYWMiOiIxZTM1ZmEzMWViZjIwNmM4Nzk0Mjg2MDYzMWVmNmIyOTMwZGNmZjZmZTllMThmODFiNTE1ODM1ZjAzMTViZGEzIiwidGFnIjoiIn0=\"}'),('773612ed-0122-42ca-a67d-697bb22090c2','f8288fa9-07fa-469f-8dde-a93508e50230','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-07 10:00:00','{\"data\": \"eyJpdiI6IjZwYzE2ZGQ4ZG94TG9HSUhaV2NMK1E9PSIsInZhbHVlIjoiYldGdXVhaURsVmUzT3Y3eU1ZMzhKOFlaSmVPS0w5TTJWWjV6K3BYQlZ6OXdzb2VUb3AxdDdPcjZVU3kxd1U2cCIsIm1hYyI6IjdmM2FjMzFjNGQzODFmYTM1YzEzNzUzMzMwMzQ2OWNmNDc0ZDZlMzc0NzU4YTkzMmE3MTNmZGRkNmQxODgwYjIiLCJ0YWciOiIifQ==\"}'),('78060b93-9ab1-438c-ab07-725fc27bc4a2','98990b01-761f-4890-a75e-75828b816d86','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Ikhsc2VoR21iTWcwQ2RVcllPWXIzcWc9PSIsInZhbHVlIjoiYUc5WlVNYWkrQ3l5WVZmZ1ArRno4R0VTamhTekIzS3B6TjNrZ0p0OWx3L3loLzVTNDlNWGtmKzJPMDhESE0ySCIsIm1hYyI6IjQyZjc3NzE2NzRkMjE5NzZmNjRkMzJjMTc4Y2JmNjY1NzY5NTI1NzRmMzRlNDBmMDA5MzM0ZjU1YjI3MmY4MjIiLCJ0YWciOiIifQ==\"}'),('81e9a03c-95d5-4480-afd2-cfad22f06ceb','f410fc5e-18b8-47ed-b7c2-48bc61e70c2a','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6IjNrZE1kZGxSaHRrZnNKMmdncERSU0E9PSIsInZhbHVlIjoiZ2plZSszdWdsL1ZCVldqWkVyUmRpOXArUWh4U1RMdW5JTXk1c1dyRGZCQT0iLCJtYWMiOiIyOWIwNjFjNDg3OGNhM2YwOGM3NWMyMjU0NGZkNDdlNGE0MGRlOTc2OWJjOWI5NjY1ZGIyYjU3YmU2MzJmODhiIiwidGFnIjoiIn0=\"}'),('83349b03-b92a-4346-b2ee-988b0cb31a05','9e1e3021-412c-42b3-ab3e-d94fbe7d15a6','817e9947-0a90-45e8-9dd0-d1e7de1e443c','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6Ino2c2hYeVZNeEIwMEpFWGxRdjNYVUE9PSIsInZhbHVlIjoiZHo1STJNa29Hd2RaYnNhc0hRR1ZML0o4Y0xKME8wLzlJQkt0QWo0eGtndFBrbVJZR0hKeGc4Z001Wm5ZYUw5NyIsIm1hYyI6IjMxZTk4Zjk0NmU0NzRjYmFhM2VmZGM2YjJkOGFlMWNmMWYyZmRmMTUxYTMyNzk3YWM3MmNmYmRhOTkwY2FhODkiLCJ0YWciOiIifQ==\"}'),('846cc2a0-cc99-4970-a8c6-cf94397e29ab','1776b150-4ff6-4ddf-ae24-f5f90da68c19','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6InZ0RkMyb2VDMmQ3SFQ2RnNra3JpSnc9PSIsInZhbHVlIjoiRlgyNE8zTHl0L2pzUmtSZUVOaWhMSVFBUkJ2YTdoQnJaVEt3OXFIbTNkOD0iLCJtYWMiOiI4ZGZlNDQxNjFmMTIxMGE3ZDIyMmUyMGE3OGM0YmRlYjI0OTVmMTk5NWY1M2MxODc4NmUwNDg5YzIwZTJjNWYzIiwidGFnIjoiIn0=\"}'),('8d5ff351-686a-44d7-9e27-989c63ae2bb7','e0228b73-0f73-467e-a7a8-3b8e578e36fe','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6IlR0RFkxMlhJZ1pobDE0TDZ6UnpnU2c9PSIsInZhbHVlIjoiY1VmWlorN3JEeDV0bUl3d2txNTFNUVl3di9ad2JXckNjY3p0R1hTak5qST0iLCJtYWMiOiJmMzJmOTE0ZThiYzQ0N2UxNDA3NjZhZDk0ZDEyMzU4MmMzZmVjYTE0ZDM5ODg0MTdjZWMwNjQyOGFhZTEwMDU3IiwidGFnIjoiIn0=\"}'),('8f9a659c-8e40-4052-b775-9025726f29fd','bb189117-5055-4455-ae8a-5a26b6e6f196','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IlQxL0pzMlB1RWhGWFhtdkk1ZGRwVGc9PSIsInZhbHVlIjoic2FaOEtkMVhKaEg4MFRMTGpPL2tKUS9DRGgzMkJJdUs2M1RZUWlrR3Y1Yz0iLCJtYWMiOiIyYzQwZjBlYjAyZTFiOWYzMjBiMzg5ODhlZjM5NzBjMzljNjhmY2Y5NmY1Y2FmODVhMTM5OWNhZjQ2MjlhYThlIiwidGFnIjoiIn0=\"}'),('8fbd9755-7030-47d9-857f-4045ec10c25f','18598738-ecf0-4d67-a54c-42ef2c527ab1','3467c3ce-47fb-407e-b44c-2deef72f4747','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6ImdVWkdUeENNSUUzK1htZ1EyTGtDb1E9PSIsInZhbHVlIjoiVnhsZWRBWUNUZHY2U05iVlZOK0ZDVkFra0tsOGJRZ1BsWS9lWkE1SEVBMUJiRHdKcTk5U1Y2MmlmUTRCOEloSSIsIm1hYyI6Ijc4NzExNjMwMzk3NTYxZTdjNTM1ODg0MmIyYTNjNWRkOTY2MGI0OWY0MjAwY2ViYmU2YTY4MTdiOTNkMzA3NzkiLCJ0YWciOiIifQ==\"}'),('95e85f89-b06c-43d5-9614-baf6a6daed09','bfb8e64f-830d-4297-a0d7-e4c7d42ff4b3','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-08 02:31:44','{\"data\": \"eyJpdiI6IlV0Yjg0S1o0dEIyaHQ4eFFqcFNBZnc9PSIsInZhbHVlIjoiUVAzTjdCWmIwR0lhOFJzd3JPcjBxcnQ3QUduYWp4MVM3cm5Ga2ZVV2JlVT0iLCJtYWMiOiI3Y2ZlMWI0MzRiZTI4ZWQ3MmVhZjZiZDI5MTcyYTNjNGM4ZDVhZGQyNTg3NjQ2NTYyNGUxNzZlNmVlMWY3OWY1IiwidGFnIjoiIn0=\"}'),('9720036e-2e93-492a-858d-3e3bcce8a877','a9f70025-972e-475c-81d7-820c59c71759','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-07 02:31:38','{\"data\": \"eyJpdiI6IkFCVFVTY3d2NjMxVWZQdUdPcUkwL3c9PSIsInZhbHVlIjoieEloZWNmQ3JwRTZ6amJHWDB5Nm1EbWlzZ1c3amFUYUpkMVBaZS8wSGhEST0iLCJtYWMiOiJjMDE4NjRkZTUwMWJhNGFiMTMxNjM2ZDIyNTNjZTFiMjM5Yzg2NWUwMDgzNjNlMjhlYzhkOTMwNzRkNzNjYWJkIiwidGFnIjoiIn0=\"}'),('9adae36b-6a37-40fa-8732-b55528b010f6','84f45d70-5888-4fae-93ee-9923d6067cae','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-11 02:32:00','{\"data\": \"eyJpdiI6ImpoRnUweTdVYUZ5YUNITkFIQXh1TkE9PSIsInZhbHVlIjoiQ3E5eXdwRks5UEhHdmF5aWFOTDIra1pIRkRQQUxFWkE2R25IR3ZpWlQ3ND0iLCJtYWMiOiJhZTVkZTM4YWIzM2JmZjVkMmUxYzVhMjdhMDEwODgwN2ZkNGEwNWY2NGUzNjUzZmM4NjJmYTJiYjIwOTg1NDQ0IiwidGFnIjoiIn0=\"}'),('a0c12db8-ac87-4648-8b51-1f764cb81018','907a8e1a-38b3-4cb1-bca9-6bd2ad0b3c3e','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6InZaMTk4WHl1MTRiZHFzTmkzVEEzTlE9PSIsInZhbHVlIjoiSVlaOWxHaDM1ZmxrM1JTeUxFS21kK1F4SUJEeHFUOVlyODRvNmlJbWdpZz0iLCJtYWMiOiJmZTkwOGVmNmMxY2IyOGQ0OWFhYzgyMGU5NzAzMTMyMDIyMjYzNDU0ZWYyZjhlNTBiYmRhNTRiNWIxNWVjY2Q1IiwidGFnIjoiIn0=\"}'),('a241db12-aa8c-450f-9742-011e114ae6cb','6b8cacfb-94dd-4b27-be87-b6b6ffa822b6','32586ad1-7956-476e-b341-c72682de18dc','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IkNjSHh1T3BnRHNPS2lXcmEweU1taVE9PSIsInZhbHVlIjoiSXVjZG4zd01reG5FN2gvKzhJa2FoazBPV3NQZmFKRklMVkxGZ255MVNwST0iLCJtYWMiOiJhNWY4M2I2NjYzZWViMWE1MDFiM2JlNjQ5NjNmNWY5NzUwMzg3MDViOGNkNjE2YzExZTkyYzQxNzk2NDI0ODUyIiwidGFnIjoiIn0=\"}'),('a3b5a9f4-ac96-4fd7-a341-d044dc29d948','db5b47ee-5cf1-4e08-8354-da5eeacddf24','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6InhXdjZ6b3hlRG55NVo4ajlpMUZCTlE9PSIsInZhbHVlIjoidXNKTGtKRmdUNVRhNDkrWVhyM2Z2WWd5Zk5rN0lWV05VTEVpRmEweG90cz0iLCJtYWMiOiI3NDg5ODkxNGM4ZjlmNGJmNmU5YmVlODFiYjI0ZGFhZTg2MzcxZTdiMTBlMWI4ZTRhZmFiYjYwZGYxMTcwYWQxIiwidGFnIjoiIn0=\"}'),('b0b303aa-df8f-4c6a-854f-43c43ad4f6a5','09f52cf3-8076-4559-b48f-b0336f4cd826','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-02 10:00:00','{\"data\": \"eyJpdiI6ImFGcXhSbURVbmwrRjdjMEI3QkV1b0E9PSIsInZhbHVlIjoiNHh0eXpnM0d4SHlWM3hUM3FYMGN2NnJlMGpMdEhLalAyVGRJZkpBOEpta3c4TlprVTJhYWRkcUdiZjBLSkRKbCIsIm1hYyI6ImJlYTgxNTcyYmUwYzZmOTQxZjI4MTgzNWFlOTg5NDMxNTFjZDY3MTBiYTBlNGM1MzQzODI4NWE2NzY2MDQyNWQiLCJ0YWciOiIifQ==\"}'),('b4226d7a-75f7-445a-8d29-1989b5146cf3','b0e0d8d1-6d67-485b-8b15-daf2a5bd666e','32586ad1-7956-476e-b341-c72682de18dc','2026-04-08 10:00:00','{\"data\": \"eyJpdiI6InhYYkIxa1ZQcU0vVjJFb1lya0JMMkE9PSIsInZhbHVlIjoiME9IMG5WRjBtSjlKTUpCTzJVRENDRS9BWlF0aXg4Y2RSdDZoNmgwSnRYTT0iLCJtYWMiOiI5MGQ2NDczODBiN2YyNzBkMzc4ZDRmMjI1NTUxZGI0OWU0ZDg5MzcyNzc2MDhlZjcxNWM3OGFkNjY3ZTgxYjk5IiwidGFnIjoiIn0=\"}'),('b5705c24-c59a-4be2-ad0f-b2480e7b965d','724bd9ef-ebe3-444d-99db-04aa59e4cb1a','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IlRXNWNLR0xJQ2dGK25NL01zL21IbWc9PSIsInZhbHVlIjoiREhncjZVRytvR3VXRUxIWEhFakVYWmZhbWJ4Y3dZajVTN2lHMlB1ekRQUT0iLCJtYWMiOiI4ZTZlMWY2ZGRkYjhlMGY2MjQ0ODMyZDlmYmJmNDMyZjExNGNiMzEyZThhOTU2NGVkMGZiYzFkMDY1NjFlMWE5IiwidGFnIjoiIn0=\"}'),('b6de8f01-a478-4c6d-9377-c90fea2b80eb','700045c9-73c0-44df-b5ad-15cec6eac37c','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6IjZKQjdrWU02Y0srZlNvWkZpSHBBOEE9PSIsInZhbHVlIjoiVnFHLzM0ZEg0T1pSRU4xWWgvNVUxSFhuZ09FOHl5TTVIdmZiWEh4dCt1Yz0iLCJtYWMiOiIxMDlkMWQ3YTM1NTUxNTNjOTAzMTcxM2FmMzE4YTQ0ZWFkZDljNjAwZTBjNmY4MGU1NjM4YTNlYjkxNmY4MGQ2IiwidGFnIjoiIn0=\"}'),('bde7c53a-5a83-4ad0-b629-9c787b545152','302c7869-2628-4a6b-b2cd-e2899905e0a7','600197de-bdf8-4a97-9238-53d514debc2e','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Ijc0ZDRYKzZJdHM3U2p2SE42aEhvZGc9PSIsInZhbHVlIjoiay94U3c1WWlVL2hCdlJDbC9qU0FoWFRIZk81S0dmeFFYUzE5YWt1T0RtQTg2VFE4ZXVrUVo1V1JUUmYvTTRXWiIsIm1hYyI6ImFiNDZkZGM0YTEwNDNkNzVlNTk0NTFhZTk2YjYwNTkwMTJkNDEyZjNkMzIzOWJhMDVlMzAyNTI3ZjFmNWE0NmIiLCJ0YWciOiIifQ==\"}'),('c2bc3309-991d-4e35-a66c-d98406bb8c83','b6c964a8-c31c-4584-ac0a-cce3d2ad19f7','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6IjFjNlBMelZFeGpUUGxubGZTSERnWWc9PSIsInZhbHVlIjoiNEFBWlFFbllvaHdiNE1MTlRIUGhQd3BSbGpOc1Fud3Zobzg1dVlkb1VKbz0iLCJtYWMiOiJmNWZkNWY1NjE5NGZhMWRiNTc2YmRjNjEwNGU2NDI1YWNjNDYyZmNhYjQxZGQ3ZTAzOGQ4ZWM1YmU4OGJhOTRhIiwidGFnIjoiIn0=\"}'),('c87aaab9-93be-4949-bc84-6f4b6238a950','10c02a45-7dff-4458-9473-9d1af83a908c','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IkNmV3k2Smdtc2RqSHBOTi9tV2tQOUE9PSIsInZhbHVlIjoid2djenZORUZNdUxjT3NrNDZuaHNEbG0xZDRtSTFEWHhIcTdRWmxOZzkxYz0iLCJtYWMiOiI4NTExNTk2MzgzOWNhNTE3ZTJmMTRhYTBmZGUyYjZjMzY5NDI5ZjI0NzExN2ZkZDdlNmJmNDM2MjU3M2NmM2IzIiwidGFnIjoiIn0=\"}'),('cd9457fb-e74e-4498-b22b-ad2d9611b5d9','f9b72071-2375-41d9-983d-9727eff534b1','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IjdGTFdnVGNJbUozNHZ3RnlVcXNSR1E9PSIsInZhbHVlIjoiQ0ZPYWFxQjNhOGk4bTFHQmZxcWdnRUlPQ3Y4THptMG5iRHF0alAzbWYvQT0iLCJtYWMiOiI1NmFlMTQzNzFhNzI3NGQ1ZTEwMjZiZDk5NjQxY2JmMDliOGQyODExMTU3MTU1Y2JmZmRhOWY4NjFjOTg5NzNkIiwidGFnIjoiIn0=\"}'),('ce326686-f801-4f28-bce6-d5663d9745b8','fa38dfea-ab98-4699-a9cc-32f1568ab3c2','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6Ikh3Q2NWUFRWTzNDQzF1cUFOTXRZSEE9PSIsInZhbHVlIjoib2x5TWRDU0RpbUc2TVlqalplanM3bmxrZzhJRE1SajVuaVpGRkhSSUVkWT0iLCJtYWMiOiI0NzcyM2VhNTRmZTE4MDUzMzI3M2FjMjRjMDkxMTY3YWExM2Y3NTQ1NTkzOGU1MDlkMDI3N2Q1NWY3ZDUzZmY0IiwidGFnIjoiIn0=\"}'),('ceb735a3-8f8a-48fe-9bc9-f5624ce70caa','be31b25a-50ae-4696-8ea7-25bd58d94d48','32586ad1-7956-476e-b341-c72682de18dc','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6Ikh1Y21EREU2ZUtFcldqenVhSDJYZ3c9PSIsInZhbHVlIjoiYWdDQ09lOGRIVm11Q1RFRG94R0t0YWtsVG9xUzFCMkRWbGM3c2hTUmE0UT0iLCJtYWMiOiI1NzQwZTY5ZjRmYmYxMDMzYmE3Mzk1NzVkMjU3ZTBiYzc4NzMyZDI3MTExNjRjNWNkOTMzMzRjNDM5OWRhZjEzIiwidGFnIjoiIn0=\"}'),('cf23c9b4-1662-4c67-83d3-0ff1e92b71ec','7618c5e8-e605-4a8a-8c79-42242253261d','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6ImhCdVpxN2FEU0N0NTZUekordVo0RlE9PSIsInZhbHVlIjoidkJwR3pWem9xK0w5UHBJOVhGKzZTMERJa1lkdmZab0haTTRwaE5hZ2lpOD0iLCJtYWMiOiI4NTE3NThjNzRlMzE3OWIwM2ZhMTUzNGI2NWI1ODIyODdmMGQ3YTJlN2UyNjhkMTUzMTlkYWM2MDZmZjFlYWUyIiwidGFnIjoiIn0=\"}'),('d9805358-9e5c-4d3b-a275-6e74a21fd901','4c358a45-b579-4740-9782-1436c29fd555','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6IlQzSlRPSGhlSm5xZC8yWVVGSks1elE9PSIsInZhbHVlIjoicGJPamJFSUJDZGszZW9qU3NtN2ViRyt6SUJ2Q3BEdFVUNmUyN25ydm9Ldz0iLCJtYWMiOiJlMDU5N2M5MzRkYTIxMDRkNmI2NTJmYTlmYjRlNzYwZDg2ODdkM2I5NmI1YTZmNzg4MGQ5MThhODg4MjY5NzRkIiwidGFnIjoiIn0=\"}'),('e0982c88-b056-44c3-b867-e019a32fccbc','e839bbec-a2e7-4bfa-9ffb-420baaa21295','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-12 10:00:00','{\"data\": \"eyJpdiI6IndXUE5WSGEvQUM1L0cwamJveFBwd2c9PSIsInZhbHVlIjoiZkpFa3ozcVBVejRuakZwcnMwR05wdzdrK2Z3VThHNW9KdHVyRklhRm52TT0iLCJtYWMiOiJhYTY3NGJmMDg2NjEwZjEwZDA0ZDhmZTdkODI3ZDI5ZjlhODZjZmIxYWVjN2Y0MTZmODljZjQ4ODcwY2FlZTAyIiwidGFnIjoiIn0=\"}'),('e1d17ccf-fea1-4964-af61-26dd55780d26','81185fbf-fdde-4d28-a420-ef485d9155ab','3467c3ce-47fb-407e-b44c-2deef72f4747','2026-02-01 10:00:00','{\"data\": \"eyJpdiI6Im40ais4REQ5RE96ZXd2V2k2cnhoYUE9PSIsInZhbHVlIjoiVE14RlZwZUNkYXhoSTA5bmNhU2N1cVh1VDQwUnBjdW92SjBCQnNTWjZTejhvQWtnazNXZ3FjTkgzTU5mNUwzSiIsIm1hYyI6ImJjOTc2NGQ0Mzc0Njc0MGVhZTEwMTEyZTBlMWZmMjdjMDBmZjVmNDkxNDAzMDUyN2U1MmQxZGE4ZjM1ZDQ2ZDYiLCJ0YWciOiIifQ==\"}'),('e505f61f-b986-48c9-8e1f-e6c39e2e74ad','dafd98b4-0e35-4b5e-84cd-33226700eb4e','600197de-bdf8-4a97-9238-53d514debc2e','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6IkFnWEU5UXFmMlBod1FoSTd3QkV2YVE9PSIsInZhbHVlIjoiVE5vRUFudmVYY2d2MENrRFdiMFBCVXFXcitWODRUYmhvNGxTaklYWFBlZmZoMmJZVXZ5cnJzSXpxelhIOU90NCIsIm1hYyI6IjMyZjVkMTdiNzdiZDk3MTUxYzgxMzIzYzQ2NmRkODc1NGJiNDJmMjYxYTAwMjk1NGFjZDY2M2Y0NTM3M2ViMmIiLCJ0YWciOiIifQ==\"}'),('ea520fc3-c800-4d05-912b-1de904aa421f','336cc250-4273-47d9-9b85-05030e68ee7d','699950d5-86ca-44ec-9473-e64f5659b004','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IlZVOFI5bDRSR0QvT25jUEViQlFlV2c9PSIsInZhbHVlIjoibmQzR3lNVWF3ZHRlUzhkTXZLSWFESkZBVlc3NzZPb3hZM3phbkRURTVqcFczRFpPdENkRkhSeVE5VEhXNXR3WiIsIm1hYyI6IjIwZWNkMGZjOGUzODcxYmM3NzkyNzRiNWRlYmM3YTRkZGNmZDg5YmVkMWY4MzMzYjRmNDg0ZWI3ZDNiYThmODMiLCJ0YWciOiIifQ==\"}'),('eede0f1e-123a-43a5-99e1-14d328d4ebe9','af4fb0c5-08b6-4b01-8eba-833eccc3253c','c98b30fa-2642-4778-9e81-78bee05a62ec','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6Im13dnZmQ0xETUp1TE0vTmZUbW4yTXc9PSIsInZhbHVlIjoiUmd3N0lPdlNUYVA1dHhvOGhnR0h2a3paMmk2bzlWZG9ScnZ2TklBT2NsMjk1bERXTk9QbmduM2Z4ZDlzNUpBcyIsIm1hYyI6IjQzY2JmNDU3OGNkNzgyNzJhNmU5NTY4YjY4M2M0YjlmNGM0ZDEyN2Y1MmFjYmQwZTRhYTljZjQyMzUyNTlmODkiLCJ0YWciOiIifQ==\"}'),('f08dced1-965d-450d-a815-971887b67b10','8d86c137-3b38-40a6-9c72-c1f64818ff12','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-09 10:00:00','{\"data\": \"eyJpdiI6IlhYS09HWDFiT0FiWGtubDM3SER5UlE9PSIsInZhbHVlIjoieWh6dXovWkI4ZVhBQ1JaSDNTRms1SkpSNFR4cG5xMGZMT1REeWx0Ujh2cz0iLCJtYWMiOiIyYjI1YjRjODJhYWNhYTU3ZGQ3YjRkYjU1MmQxZjMzN2RmM2MyNDA2NzE2ZmVhMWQ0NDA0N2RkOGJkMGM4N2IwIiwidGFnIjoiIn0=\"}'),('f295e428-1147-46f9-a707-ec6aca102b01','4b1e733a-d7ab-46c3-91f0-6dcd647813bc','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','2026-02-02 10:00:00','{\"data\": \"eyJpdiI6IkxqTWxBczg1dVVnTWJEejBUenVIOFE9PSIsInZhbHVlIjoiVGh0QXBYWGJJWm01RVVQVExvVlVKYzN5N1VDRmhPbWJlOVMrV1NyZityL3FOTndudG43eHpSVUszTXNZMm05VyIsIm1hYyI6IjU3ZTAzNjc3ZjYxYWZjZDg2MmI0NzY5NGM2ZDY5MTI4NDM1ZjI0ZTVkMTdlM2E2NWYxOTgwMWY4YTY4NjUyNTIiLCJ0YWciOiIifQ==\"}'),('f7af3a93-eef1-4463-afc3-38faec4e6137','ea0da990-6b63-4c84-8070-4b31034bde38','9929bc57-d157-467a-9d9c-24b56a6863e9','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6IlMvbk5nZzF4M25aNlgzbUpZZnJxRHc9PSIsInZhbHVlIjoidXlMUXMweGpjWEF1NnYvMHBJUEZ6ZXZ0NnJNZFlnQm1Vc3Rja0toaHJpYz0iLCJtYWMiOiJlZWU5OWU0MWU3Mjc5ODc4OGZiYjU3M2IzMGFjNzdlZmY5NTA3MDFiZjAwYWY3YzlkOTYxZDk2MWZkYTA4MmRiIiwidGFnIjoiIn0=\"}'),('f8bae918-75db-43c0-964f-06e77d884a41','cd1b1590-c671-410c-a6f1-233412dba2c7','9209c193-fa25-432f-85e5-96e96ade32ed','2026-04-10 10:00:00','{\"data\": \"eyJpdiI6IkJJak5meTVyQnNKanVyQjVPRU9KcHc9PSIsInZhbHVlIjoiMENnQWJXT0F1WlJrSEk3b0pRYytJTDlsM0FFUVBkSTdMYjZOV0pSaTBOYz0iLCJtYWMiOiIyYzBmNzY3YzNjZjIxMmZjNjMzZDYwYzA2YzYxNjBjYzI1ZDY1ZDZhNzhiZmZhZDQ3OGMzMjI4MTFiMWIzMDRjIiwidGFnIjoiIn0=\"}'),('f90a01a2-7579-4923-b619-3c75edb89eb9','9e470088-b1bc-4df8-a95a-5db5ecdad6c1','32586ad1-7956-476e-b341-c72682de18dc','2026-04-11 10:00:00','{\"data\": \"eyJpdiI6Imd1RVJZaUZrTEQxc1lzSm5DUlR2V3c9PSIsInZhbHVlIjoiR3BUakRmVVQ0K3RkMVRqSTk3ODNvWGcvOWNLUkVzT05hQzZtK09Qc1R6RT0iLCJtYWMiOiJlN2FlMzk1ODRhMzk5NzJiYmZiOTA5NjJjMWIyOTJkZjc4NmQyY2FmYmQ5NGQ0ZWYwMDM0MWE4NzUwOWNjOWQxIiwidGFnIjoiIn0=\"}'),('faeec8ad-1c75-4a24-b927-c0c07302f49c','9c0119f1-a90f-4347-ac05-bd1a5458e556','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6ImxMZnVUL0E0VTUxYWtsQmJTS3RzN0E9PSIsInZhbHVlIjoiVlYxRndQWFh2WW1hSmdmU01NZFV6VDMvajBqOG9rSVNTOEtKRmNQbUpSTT0iLCJtYWMiOiI0M2Y5NTI3NGI2ZDE0Y2RlNjUyZGRjNDc2ODU4YWRkNmIxMDY2NmU3YjRkMzE0NDRmNGU0N2UyYjdjZjk4NWI0IiwidGFnIjoiIn0=\"}'),('fc31da1f-8b1f-4b9f-969f-18e1d2696e5a','646c47f2-fd92-479c-a337-70863e7a28b5','e7e74f59-fd88-47f2-8de8-bf345109b9e9','2026-04-03 10:00:00','{\"data\": \"eyJpdiI6IlRZWFNUVU9aWWhXcy9hVTZIQ0R2QWc9PSIsInZhbHVlIjoiNVFzUUhzY2h5WkFIa2hoYXNNUnhBQm9zMTVhQmRNUjFtSE1RZ01GdHJOU0RuZk1mdWlaZ0xWMU82eGhnMHFWaCIsIm1hYyI6ImE4M2UzNTExOWMxNDM3ZGVmYzc5Mzk0YTI5NzU3Y2QyMmUyNzVmM2U1Nzg4ZTA2YWE4ODNkYTJkYWNkNmI5ODQiLCJ0YWciOiIifQ==\"}'),('ffa01be2-c948-4ab6-89b1-8314ff2aee31','cb2ba0d0-8f91-460c-af12-f31d13693c6b','fb04e079-f2c1-45b1-9733-71aa5e52896c','2026-04-13 10:00:00','{\"data\": \"eyJpdiI6IjhVUnM3OGhiWU9EWmFycE12NlFMdGc9PSIsInZhbHVlIjoiaVRORGM4VnhoT0hBekxWRFQza05XMllydEo2U3dWUGN2azQwRlJwNFBWUT0iLCJtYWMiOiIzODg4ZWNiOTM1NjUzNjYwMjViN2Y0ZDY0MTk1ZGQyZTI2MWU0YjE1MmQ5ZjUyZDQ3ZGNlMTJiYTM0ZDU5MjY3IiwidGFnIjoiIn0=\"}');
/*!40000 ALTER TABLE `health_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `health_goals`
--

DROP TABLE IF EXISTS `health_goals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `health_goals` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metric_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comparison_operator` enum('<=','>=','=') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_value` int unsigned NOT NULL,
  `timeframe` enum('day','week','month') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'week',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('ACTIVE','MET','EXPIRED') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `health_goals_account_id_foreign` (`account_id`),
  CONSTRAINT `health_goals_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `health_goals`
--

LOCK TABLES `health_goals` WRITE;
/*!40000 ALTER TABLE `health_goals` DISABLE KEYS */;
INSERT INTO `health_goals` VALUES ('a004dc43-6a52-43ac-bf33-5d437d0d8fa2','699950d5-86ca-44ec-9473-e64f5659b004','weight','>=',2,'week','2026-04-01','2026-04-19','ACTIVE','2026-04-13 00:19:53','2026-04-13 00:26:58');
/*!40000 ALTER TABLE `health_goals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_02_01_031102_add_two_factor_columns_to_users_table',1),(5,'2026_02_01_031310_create_personal_access_tokens_table',1),(6,'2026_02_01_031312_create_teams_table',1),(7,'2026_02_01_031313_create_team_user_table',1),(8,'2026_02_01_031314_create_team_invitations_table',1),(9,'2026_02_01_031735_create_audits_table',1),(10,'2026_02_01_060505_create_patients_table',1),(11,'2026_02_03_013145_create_accounts_table',1),(12,'2026_02_03_013951_create_authentication_credentials_table',1),(13,'2026_02_03_014055_create_two_factor_methods_table',1),(14,'2026_02_03_014517_create_form_templates_table',1),(15,'2026_02_03_014557_create_form_fields_table',1),(16,'2026_02_03_014636_create_form_submissions_table',1),(17,'2026_02_03_014733_create_health_entries_table',1),(18,'2026_02_03_014809_create_dashboards_table',1),(19,'2026_02_03_014848_create_health_goals_table',1),(20,'2026_02_03_014931_create_reports_table',1),(21,'2026_02_03_015011_create_aggregated_data_table',1),(22,'2026_02_03_015039_create_audit_logs_table',1),(23,'2026_02_09_184849_add_approval_fields_to_forms_table',1),(24,'2026_02_10_000953_create_permission_tables',1),(25,'2026_02_10_050449_add_approval_fields_to_forms_table',1),(26,'2026_02_14_061839_create_form_template_versions_table',1),(27,'2026_02_15_054152_add_title_and_schema_to_form_templates_table',1),(28,'2026_02_15_054607_drop_status_from_form_template_versions',1),(29,'2026_02_15_233628_add_defaults_to_form_templates_table',1),(30,'2026_02_16_055828_alter_personal_access_tokens_tokenable_id_to_uuid',1),(31,'2026_02_16_070826_fix_jetstream_and_sanctum_for_uuid_users',1),(32,'2026_02_17_052311_add_timestamps_to_form_templates_table',1),(33,'2026_03_01_045426_add_account_id_to_users_table',1),(34,'2026_03_02_025437_add_reporting_fields_to_audit_logs_table',1),(35,'2026_03_02_210156_alter_sessions_user_id_to_uuid',1),(36,'2026_03_02_235252_add_required_field_constraints',1),(37,'2026_03_11_220144_create_researcher_cohorts_table',1),(38,'2026_03_12_221712_create_participant_profiles_table',1),(39,'2026_03_13_200533_add_goal_columns_to_form_fields_table',1),(40,'2026_03_15_192235_create_provider_patient_table',1),(41,'2026_03_17_add_is_admin_to_users_table',1),(42,'2026_03_17_add_moderation_to_reports_table',1),(43,'2026_03_20_000000_create_provider_feedback_table',1),(44,'2026_03_23_185205_add_reporting_indexes_to_form_submissions_table',1),(45,'2026_03_23_214702_add_reporting_indexes_to_health_entries_table',1),(46,'2026_03_26_015954_add_purpose_to_form_templates_table',1),(47,'2026_03_30_232450_create_report_updates_table',1),(48,'2026_03_31_055347_create_reminder_settings_table',1),(49,'2026_03_31_055558_create_notifications_table',1),(50,'2026_04_03_045300_add_link_to_notifications_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES ('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d83ff-bf48-709a-966b-e755fb32f9e9'),('4e5dffd2-95f6-4df1-9a9f-5943ef962198','App\\Models\\User','019d83ff-bfd5-72d4-9124-08a311f7e0ac'),('74b31cd8-40e0-44d4-bd4d-fcdaaf114a85','App\\Models\\User','019d83ff-bff5-7262-ad8c-4fe269b7b3b2'),('868d7687-6149-479f-bb6c-a95a3d2acec0','App\\Models\\User','019d83ff-c01b-7188-b72c-dc4d22d92aaa'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d83ff-c11e-70ef-8033-cba9ae9ef71a'),('868d7687-6149-479f-bb6c-a95a3d2acec0','App\\Models\\User','019d83ff-c3c0-71e6-b54c-865dec35bfba'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8400-5672-736f-bd78-a3f99560e9bd'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8463-f8e9-71b0-8593-6a139a66fff4'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8464-0bb8-7271-b10e-ec2aa5076fc1'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8464-22ed-70bf-8460-614874ce8f50'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8464-382b-70ae-a810-db2d583745af'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8464-4ef0-721c-8d57-5a68d02a1114'),('4e5dffd2-95f6-4df1-9a9f-5943ef962198','App\\Models\\User','019d84b0-7661-71a0-ae80-ed13591bb7bb'),('4e5dffd2-95f6-4df1-9a9f-5943ef962198','App\\Models\\User','019d8952-e740-7144-a1f1-4cf36e0137d0'),('868d7687-6149-479f-bb6c-a95a3d2acec0','App\\Models\\User','019d895e-db95-720f-81a4-189484b84525'),('b2564130-6ed7-4e04-bf28-f5135032f439','App\\Models\\User','019d8994-073b-732d-ab7b-7861511bcc50'),('74b31cd8-40e0-44d4-bd4d-fcdaaf114a85','App\\Models\\User','019d89a4-c498-731c-8e5d-ed0c823363af');
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unread',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,'e7e74f59-fd88-47f2-8de8-bf345109b9e9','reminder','reminder test',NULL,'unread','2026-04-12 23:21:09','2026-04-12 23:21:09'),(2,'e7e74f59-fd88-47f2-8de8-bf345109b9e9','reminder','reminder test 2',NULL,'unread','2026-04-12 23:21:09','2026-04-12 23:21:09'),(3,'e7e74f59-fd88-47f2-8de8-bf345109b9e9','alert','alert',NULL,'unread','2026-04-12 23:21:09','2026-04-12 23:21:09'),(4,'e7e74f59-fd88-47f2-8de8-bf345109b9e9','alert','alert 2',NULL,'unread','2026-04-12 23:21:09','2026-04-12 23:21:09'),(5,'e7e74f59-fd88-47f2-8de8-bf345109b9e9','alert','alert 3',NULL,'unread','2026-04-12 23:21:09','2026-04-12 23:21:09'),(6,'2bddb97b-2da4-4521-a6cf-f9d3a3558469','provider_feedback','Your provider added new feedback and recommended actions to your profile.',NULL,'unread','2026-04-14 01:35:42','2026-04-14 01:35:42');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `participant_profiles`
--

DROP TABLE IF EXISTS `participant_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participant_profiles` (
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`account_id`),
  CONSTRAINT `participant_profiles_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participant_profiles`
--

LOCK TABLES `participant_profiles` WRITE;
/*!40000 ALTER TABLE `participant_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `participant_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_feedback`
--

DROP TABLE IF EXISTS `provider_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_feedback` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `recommended_actions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_feedback_patient_account_id_foreign` (`patient_account_id`),
  KEY `provider_feedback_provider_account_id_foreign` (`provider_account_id`),
  CONSTRAINT `provider_feedback_patient_account_id_foreign` FOREIGN KEY (`patient_account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `provider_feedback_provider_account_id_foreign` FOREIGN KEY (`provider_account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_feedback`
--

LOCK TABLES `provider_feedback` WRITE;
/*!40000 ALTER TABLE `provider_feedback` DISABLE KEYS */;
INSERT INTO `provider_feedback` VALUES ('819bf2ac-7141-4e65-9360-ea51c9ab5c04','2bddb97b-2da4-4521-a6cf-f9d3a3558469','2cc44de1-c03a-422a-a9c5-14018c8ea074','Blood pressure too high','Take omega-3s','2026-04-14 01:35:42','2026-04-14 01:35:42');
/*!40000 ALTER TABLE `provider_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_patient`
--

DROP TABLE IF EXISTS `provider_patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_patient` (
  `provider_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`provider_id`,`patient_id`),
  KEY `provider_patient_patient_id_foreign` (`patient_id`),
  CONSTRAINT `provider_patient_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `provider_patient_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_patient`
--

LOCK TABLES `provider_patient` WRITE;
/*!40000 ALTER TABLE `provider_patient` DISABLE KEYS */;
INSERT INTO `provider_patient` VALUES ('2cc44de1-c03a-422a-a9c5-14018c8ea074','051f76f1-0e9b-467c-b8e8-f1ededdffcf1',NULL,NULL),('2cc44de1-c03a-422a-a9c5-14018c8ea074','2bddb97b-2da4-4521-a6cf-f9d3a3558469',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','051f76f1-0e9b-467c-b8e8-f1ededdffcf1',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','0cc3c479-07f2-4a67-93ac-7866b238daeb',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','3467c3ce-47fb-407e-b44c-2deef72f4747',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','600197de-bdf8-4a97-9238-53d514debc2e',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','7c28e0f1-d0e6-4422-a7be-563b3363bcfa',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','817e9947-0a90-45e8-9dd0-d1e7de1e443c',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','c98b30fa-2642-4778-9e81-78bee05a62ec',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','e23f917d-388f-4bcf-bbd3-1b55e2fc0805',NULL,NULL),('3a47a409-6bb9-4719-b96f-78746724d6bd','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41',NULL,NULL);
/*!40000 ALTER TABLE `provider_patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder_settings`
--

DROP TABLE IF EXISTS `reminder_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `next_run_at` timestamp NOT NULL,
  `last_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder_settings`
--

LOCK TABLES `reminder_settings` WRITE;
/*!40000 ALTER TABLE `reminder_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_updates`
--

DROP TABLE IF EXISTS `report_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_updates` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `researcher_account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_updates_report_id_foreign` (`report_id`),
  CONSTRAINT `report_updates_report_id_foreign` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_updates`
--

LOCK TABLES `report_updates` WRITE;
/*!40000 ALTER TABLE `report_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `report_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reports` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `researcher_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_type` enum('Aggregated','Comparative') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  `archive_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `archived_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `archived_at` timestamp NULL DEFAULT NULL,
  `deleted_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deletion_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `restored_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `restoration_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `restored_at` timestamp NULL DEFAULT NULL,
  `moderation_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `moderation_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `moderated_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moderated_at` timestamp NULL DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `reports_researcher_id_foreign` (`researcher_id`),
  KEY `reports_archived_by_foreign` (`archived_by`),
  KEY `reports_deleted_by_foreign` (`deleted_by`),
  KEY `reports_restored_by_foreign` (`restored_by`),
  KEY `reports_moderated_by_foreign` (`moderated_by`),
  CONSTRAINT `reports_archived_by_foreign` FOREIGN KEY (`archived_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_moderated_by_foreign` FOREIGN KEY (`moderated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_researcher_id_foreign` FOREIGN KEY (`researcher_id`) REFERENCES `accounts` (`id`),
  CONSTRAINT `reports_restored_by_foreign` FOREIGN KEY (`restored_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES ('4b28c3f4-b389-4365-bc4d-3554087d9ce8','86796d79-f9cc-4a19-bb25-28cc8f9928ec','Aggregated',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10'),('951a79c3-145a-45bd-b041-ad5478445b5a','7c242f03-b521-40ae-bc00-6a30ff48310b','Aggregated',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10'),('b5f72d39-c547-472d-a0c5-d0babcbf6060','0c861910-7fb9-4979-8fd0-b3ac02fe0625','Aggregated',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10'),('bb7abc7d-6f9e-47e9-a1ef-e171093355ca','5c2eaee3-1604-4ed6-ba1e-475ed70600f8','Aggregated',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10'),('dbe4967b-89d8-4069-8aa8-8225fb9d2ef4','58a142ac-39ba-462a-bda0-864753aaf140','Aggregated',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10'),('fab5dacf-032a-40e1-8fe3-f205ef5550b7','038cd94a-c6bd-481c-b707-2c60d59d9d5e','Aggregated',0,NULL,NULL,NULL,NULL,NULL,'2026-04-14 02:09:51',NULL,NULL,NULL,'approved',NULL,NULL,NULL,0,'2026-04-12 23:21:10');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `researcher_cohorts`
--

DROP TABLE IF EXISTS `researcher_cohorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `researcher_cohorts` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `purpose` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `filters_json` json NOT NULL,
  `estimated_size` int unsigned NOT NULL,
  `version` int unsigned NOT NULL DEFAULT '1',
  `created_by` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `researcher_cohorts_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `researcher_cohorts`
--

LOCK TABLES `researcher_cohorts` WRITE;
/*!40000 ALTER TABLE `researcher_cohorts` DISABLE KEYS */;
INSERT INTO `researcher_cohorts` VALUES ('31fdd05b-6957-4938-b0ac-c2b88edbf093','TestCohort','Testing','{\"account_type\": \"User\"}',25,1,'097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','2026-04-13 03:07:46','2026-04-13 03:07:46'),('44785ce1-5a45-4e2e-b181-0e4a0744e601','test','testing','{\"account_type\": \"User\"}',25,1,'097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','2026-04-13 03:32:18','2026-04-13 03:32:18'),('caf795e9-8469-46cc-9a4b-89d1e4332b55','test2','testing2','{\"account_type\": \"User\"}',25,1,'097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','2026-04-13 03:33:39','2026-04-13 03:33:39');
/*!40000 ALTER TABLE `researcher_cohorts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES ('4e5dffd2-95f6-4df1-9a9f-5943ef962198','researcher','web','2026-04-12 23:21:08','2026-04-12 23:21:08'),('74b31cd8-40e0-44d4-bd4d-fcdaaf114a85','admin','web','2026-04-12 23:21:08','2026-04-12 23:21:08'),('868d7687-6149-479f-bb6c-a95a3d2acec0','provider','web','2026-04-12 23:21:08','2026-04-12 23:21:08'),('b2564130-6ed7-4e04-bf28-f5135032f439','user','web','2026-04-12 23:21:08','2026-04-12 23:21:08');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_last_activity_index` (`last_activity`),
  KEY `sessions_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('hncCAanaZ2BDjOivFxpBfkspvlksFqo77LPoHEzj','019d8994-073b-732d-ab7b-7861511bcc50','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiMEdTM0JobTNwNzlRRlBWR3BmV25tTFl4S05KWmNqWk10MUVDVFBvZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly9sb2NhbGhvc3QvdXNlci9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6MTU6ImRhc2hib2FyZHMudXNlciI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtzOjM2OiIwMTlkODk5NC0wNzNiLTczMmQtYWI3Yi03ODYxNTExYmNjNTAiO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2NDoiODkxZTEyYmY0Y2QxMmJmYjA5ZTAyNTVhM2I2MWRjNmE3YWZiMWY4M2NmMGZmZjEyOWY0NjQ5OTlhNjdhYjlmYyI7fQ==',1776130553),('iwABq7wvLAyQNBFuCKWswnTHHvgI3QrgajBUS5rX','019d89a4-c498-731c-8e5d-ed0c823363af','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSG5WSWNMR3FCazRzYnRoUkJCakFrSVc0SXh1RWtHWm5ZVmYwY0ltNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly9sb2NhbGhvc3QvYWRtaW4vZGF0YWJhc2UtbWFuYWdlbWVudCI7czo1OiJyb3V0ZSI7czoyNToiYWRtaW4uZGF0YWJhc2UtbWFuYWdlbWVudCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjE6e2k6MDtzOjU6ImVycm9yIjt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7czozNjoiMDE5ZDg5YTQtYzQ5OC03MzFjLThlNWQtZWQwYzgyMzM2M2FmIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjQ6ImIyZTkzMzgwZjA5ZTM1OGI1NDU1NzRiZmVjNDdmNTk0ZjI2ZWI4OTkzNzFmZTg2MjNjNzBiZTE5NWM1MjJiZGIiO30=',1776136737),('MNybKMR6TX9EukcmetevFT92Hr2447E4XSmXfHgi','019d84b0-7661-71a0-ae80-ed13591bb7bb','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoicnpSQkVTcDd3cE1HOGFQZkNqUWNiZFpGWUppVHZRTHF6R1FkU2JFbCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly9sb2NhbGhvc3QvcmVzZWFyY2hlci9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6MjE6ImRhc2hib2FyZHMucmVzZWFyY2hlciI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtzOjM2OiIwMTlkODRiMC03NjYxLTcxYTAtYWU4MC1lZDEzNTkxYmI3YmIiO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2NDoiNDkxYzFjMTQxYTQ2NGY2MmRmM2E2MmZiM2JiMzJjNDM0NjBkNTkxNTdmN2FmODExNTdkNTc2NmUyOTBkMmFlMiI7fQ==',1776055376),('MS8dAvtJqoRHE1FmSRfBoNVAQxPCZPJbMC4dynfQ','019d895e-db95-720f-81a4-189484b84525','172.19.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoibXc3ZTNOYXRaY05yUnhPa3VLMUxmUDJ5QnJCZ2dsdlNIWHo4S2xMRiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly9sb2NhbGhvc3QvcHJvdmlkZXIvZGFzaGJvYXJkIjtzOjU6InJvdXRlIjtzOjE5OiJkYXNoYm9hcmRzLnByb3ZpZGVyIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO3M6MzY6IjAxOWQ4OTVlLWRiOTUtNzIwZi04MWE0LTE4OTQ4NGI4NDUyNSI7czoyMToicGFzc3dvcmRfaGFzaF9zYW5jdHVtIjtzOjY0OiJiZjdjNzRjZTA1MjUxNmM4MDgwYjVkMTllNjI0NzVkZjk1NjZiMTRmNWQ1MzhlYmI5M2MyNDAzMDYyZDk5Zjk0Ijt9',1776130630);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_invitations`
--

DROP TABLE IF EXISTS `team_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_invitations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint unsigned NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_invitations_team_id_email_unique` (`team_id`,`email`),
  CONSTRAINT `team_invitations_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_invitations`
--

LOCK TABLES `team_invitations` WRITE;
/*!40000 ALTER TABLE `team_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_user`
--

DROP TABLE IF EXISTS `team_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint unsigned NOT NULL,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`),
  KEY `team_user_user_id_foreign` (`user_id`),
  CONSTRAINT `team_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_user`
--

LOCK TABLES `team_user` WRITE;
/*!40000 ALTER TABLE `team_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teams_user_id_index` (`user_id`),
  CONSTRAINT `teams_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES (1,'019d83ff-bf48-709a-966b-e755fb32f9e9','Test User\'s Team',1,'2026-04-12 23:21:09','2026-04-12 23:21:09'),(2,'019d83ff-bfd5-72d4-9124-08a311f7e0ac','Test Res\'s Team',1,'2026-04-12 23:21:09','2026-04-12 23:21:09'),(3,'019d83ff-bff5-7262-ad8c-4fe269b7b3b2','Test Admin\'s Team',1,'2026-04-12 23:21:09','2026-04-12 23:21:09'),(4,'019d83ff-c01b-7188-b72c-dc4d22d92aaa','Test Provider\'s Team',1,'2026-04-12 23:21:09','2026-04-12 23:21:09'),(5,'019d83ff-c11e-70ef-8033-cba9ae9ef71a','Test Summary\'s Team',1,'2026-04-12 23:21:09','2026-04-12 23:21:09'),(6,'019d83ff-c3c0-71e6-b54c-865dec35bfba','Test Patients\'s Team',1,'2026-04-12 23:21:10','2026-04-12 23:21:10'),(7,'019d8400-5672-736f-bd78-a3f99560e9bd','Usertest\'s Team',1,'2026-04-12 23:21:48','2026-04-12 23:21:48'),(8,'019d84b0-7661-71a0-ae80-ed13591bb7bb','Geofferey\'s Team',1,'2026-04-13 02:34:10','2026-04-13 02:34:10'),(9,'019d8952-e740-7144-a1f1-4cf36e0137d0','Researcher\'s Team',1,'2026-04-14 00:10:05','2026-04-14 00:10:05'),(10,'019d895e-db95-720f-81a4-189484b84525','Provider\'s Team',1,'2026-04-14 00:23:08','2026-04-14 00:23:08'),(11,'019d8994-073b-732d-ab7b-7861511bcc50','test\'s Team',1,'2026-04-14 01:21:13','2026-04-14 01:21:13'),(12,'019d89a4-c498-731c-8e5d-ed0c823363af','Admin\'s Team',1,'2026-04-14 01:39:30','2026-04-14 01:39:30');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_methods`
--

DROP TABLE IF EXISTS `two_factor_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_methods` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method_type` enum('SMS','TOTP','Email') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `two_factor_methods_account_id_foreign` (`account_id`),
  CONSTRAINT `two_factor_methods_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_methods`
--

LOCK TABLES `two_factor_methods` WRITE;
/*!40000 ALTER TABLE `two_factor_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint unsigned DEFAULT NULL,
  `profile_photo_path` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_account_id_foreign` (`account_id`),
  CONSTRAINT `users_account_id_foreign` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('019d83ff-bf48-709a-966b-e755fb32f9e9','c91f016f-6a27-44a5-ada0-1cbda7f96af9','Test User','test@example.com','2026-04-12 23:21:08','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'n16AtaafdT',NULL,NULL,'2026-04-12 23:21:09','2026-04-12 23:21:09',0),('019d83ff-bfd5-72d4-9124-08a311f7e0ac','a8d3c258-f481-4b56-9052-081c2078d854','Test Res','res@example.com','2026-04-12 23:21:09','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'4JoIVMQWfJ',NULL,NULL,'2026-04-12 23:21:09','2026-04-12 23:21:09',0),('019d83ff-bff5-7262-ad8c-4fe269b7b3b2','1a709ffd-5518-40dc-909d-6e744676beb7','Test Admin','admin@example.com','2026-04-12 23:21:09','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'us04WjqOYN',NULL,NULL,'2026-04-12 23:21:09','2026-04-12 23:21:09',0),('019d83ff-c01b-7188-b72c-dc4d22d92aaa','fd8e3f6f-f555-4aa5-b65a-f489aba8375f','Test Provider','provider@example.com','2026-04-12 23:21:09','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'opy6MyGIFV',NULL,NULL,'2026-04-12 23:21:09','2026-04-12 23:21:09',0),('019d83ff-c11e-70ef-8033-cba9ae9ef71a','e7e74f59-fd88-47f2-8de8-bf345109b9e9','Test Summary','summary@example.com','2026-04-12 23:21:09','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'9arlSesucl',NULL,NULL,'2026-04-12 23:21:09','2026-04-12 23:21:09',0),('019d83ff-c3c0-71e6-b54c-865dec35bfba','3a47a409-6bb9-4719-b96f-78746724d6bd','Test Patients','patients@example.com','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'VrGAbHE3JJ',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c3f4-7301-96b7-0302176edda4','051f76f1-0e9b-467c-b8e8-f1ededdffcf1','Dr. Euna Donnelly III','bthompson@example.net','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'3OALApt54D',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c43b-72f7-81c2-e028d1097077','c98b30fa-2642-4778-9e81-78bee05a62ec','Bailee Bartell','fconsidine@example.net','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'KKq9u8jZ1D',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c48e-7147-9034-3ff2f95c426e','b6d0b4d0-aaad-484b-b2e9-3ddc42175f5b','Demond Hilpert','cedrick15@example.com','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'fYA05tA0cZ',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c4ef-7156-bd63-adf3d86263fd','3467c3ce-47fb-407e-b44c-2deef72f4747','Dr. Keon Schamberger','wayne06@example.net','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'7MX7keOVhc',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c53d-72c5-93f4-bbc47e8d92ef','0cc3c479-07f2-4a67-93ac-7866b238daeb','Selina Kemmer','xleannon@example.net','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'tY0GKgRUu7',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c587-728c-abd7-6608e62041a2','7c28e0f1-d0e6-4422-a7be-563b3363bcfa','Ransom Feil','lhauck@example.org','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'ecMUEy8KZV',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c5e2-7375-b73b-28ef2f7431d1','600197de-bdf8-4a97-9238-53d514debc2e','Mr. Jaylen Wintheiser','alfonso61@example.org','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'sHqPnUkQoh',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c63f-71ce-8024-25f9833c542b','f4eb44e6-ef14-425d-8d4e-9b00a4e04e41','Donavon Haley','zflatley@example.com','2026-04-12 23:21:10','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'Bvo1i6rpDc',NULL,NULL,'2026-04-12 23:21:10','2026-04-12 23:21:10',0),('019d83ff-c67b-7153-8a6a-ded7eb4bbeef','e23f917d-388f-4bcf-bbd3-1b55e2fc0805','Sam Heidenreich','oschaefer@example.com','2026-04-12 23:21:11','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'xCO17xJW1T',NULL,NULL,'2026-04-12 23:21:11','2026-04-12 23:21:11',0),('019d83ff-c6cf-7287-b1c4-c98c80710a7b','817e9947-0a90-45e8-9dd0-d1e7de1e443c','Kelli Rosenbaum','feest.edward@example.org','2026-04-12 23:21:11','$2y$12$WFQWOipYV3/tGvLW78EM2OWE5WGJu26Yl2GaMoPIvisD5KijfrKNC',NULL,NULL,NULL,'IZ2CBUQfRx',NULL,NULL,'2026-04-12 23:21:11','2026-04-12 23:21:11',0),('019d8400-5672-736f-bd78-a3f99560e9bd','699950d5-86ca-44ec-9473-e64f5659b004','Usertest','Usertest@email.com',NULL,'$2y$12$Xnvdm1RQm.ewv164BZPK7.6THEhX85vC9R5/W6j3czlIyK1bT9pHC',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-12 23:21:47','2026-04-12 23:21:47',0),('019d8463-f8e9-71b0-8593-6a139a66fff4','fb04e079-f2c1-45b1-9733-71aa5e52896c','Demo User 1','demo1@example.com','2026-04-13 01:10:37','$2y$12$Xo6gWytjTJJM7KNwc4OR6.qqIQQRWET8BK6ybTd6OCRTzZ690ivym',NULL,NULL,NULL,'yPz0w29cTd',NULL,NULL,'2026-04-13 01:10:37','2026-04-13 01:18:12',0),('019d8464-0bb8-7271-b10e-ec2aa5076fc1','c99ed93c-d025-42f8-bfd5-34e1b8b47bd8','Demo User 2','demo2@example.com','2026-04-13 01:10:42','$2y$12$Xo6gWytjTJJM7KNwc4OR6.qqIQQRWET8BK6ybTd6OCRTzZ690ivym',NULL,NULL,NULL,'Jmiq3S48Te',NULL,NULL,'2026-04-13 01:10:42','2026-04-13 01:18:24',0),('019d8464-22ed-70bf-8460-614874ce8f50','9209c193-fa25-432f-85e5-96e96ade32ed','Demo User 3','demo3@example.com','2026-04-13 01:10:48','$2y$12$Xo6gWytjTJJM7KNwc4OR6.qqIQQRWET8BK6ybTd6OCRTzZ690ivym',NULL,NULL,NULL,'uN70KewgJp',NULL,NULL,'2026-04-13 01:10:48','2026-04-13 01:18:35',0),('019d8464-382b-70ae-a810-db2d583745af','32586ad1-7956-476e-b341-c72682de18dc','Demo User 4','demo4@example.com','2026-04-13 01:10:53','$2y$12$Xo6gWytjTJJM7KNwc4OR6.qqIQQRWET8BK6ybTd6OCRTzZ690ivym',NULL,NULL,NULL,'f8wIxNnO2g',NULL,NULL,'2026-04-13 01:10:53','2026-04-13 01:18:45',0),('019d8464-4ef0-721c-8d57-5a68d02a1114','9929bc57-d157-467a-9d9c-24b56a6863e9','Demo User 5','demo5@example.com','2026-04-13 01:10:59','$2y$12$Xo6gWytjTJJM7KNwc4OR6.qqIQQRWET8BK6ybTd6OCRTzZ690ivym',NULL,NULL,NULL,'zvbEGCdqS4',NULL,NULL,'2026-04-13 01:10:59','2026-04-13 01:18:55',0),('019d84b0-7661-71a0-ae80-ed13591bb7bb','097bf7e1-30f7-4d9e-b2b7-86a13bdc2064','Geofferey','Researcher@email.com',NULL,'$2y$12$nUYrn/uwfqITMbS2xDjBKe/26BE3KUnWNnjSPLh6xkY2t3pw6cG2m',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-13 02:34:10','2026-04-13 02:34:10',0),('019d8952-e740-7144-a1f1-4cf36e0137d0','70508027-2f1f-4fb5-8c82-3ec7887dfe91','Researcher','Researcher2@email.com',NULL,'$2y$12$1zAKWxc3./1qt50lU0hMYeP69ghn9LkoLcjE7.DYteYO21xnb7jxG',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 00:10:04','2026-04-14 00:10:04',0),('019d895e-db95-720f-81a4-189484b84525','2cc44de1-c03a-422a-a9c5-14018c8ea074','Provider','provider@email.com',NULL,'$2y$12$Q9/glyPJJSETrWsqN.BVRO.4Ptb25T5UnbA0ftqaZnfbDm2ikdAjm',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 00:23:08','2026-04-14 00:23:08',0),('019d8994-073b-732d-ab7b-7861511bcc50','2bddb97b-2da4-4521-a6cf-f9d3a3558469','test','usertest3@email.com',NULL,'$2y$12$1gxFoarRamsxxzpOOZ4PPuLNDyFSAjABpQ4Kr/CV5Mem2acBpfYqG',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 01:21:13','2026-04-14 01:21:13',0),('019d89a4-c498-731c-8e5d-ed0c823363af','608e6deb-5192-4a2c-8a4b-b8f49414bcfe','Admin','admin@email.com',NULL,'$2y$12$EAnVFimVU28mu1nUy8dVGels7G0cjaYBGl6/R0p3e.Sz1mQWwe8uW',NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 01:39:30','2026-04-14 01:39:30',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-14  3:30:30
